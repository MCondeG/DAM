export class Usuario{

    constructor(public dniUsuario:string, 
        public apellidosNombreUsuario:string,
        public fechaNacimientoUsuario:string) {
      }

}