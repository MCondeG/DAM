package com.ada.rutasfirebase2;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.ada.rutasfirebase2.entidades.Posicion;
import com.ada.rutasfirebase2.entidades.Ruta;
import com.ada.rutasfirebase2.entidades.Tramo;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    ArrayList<Posicion> listaPosiciones = new ArrayList<>();
    ArrayList<Tramo> listaTramos = new ArrayList<>();
    ArrayList<Ruta> listaRutas = new ArrayList<>();
    Posicion posicion;
    Tramo tramo;
    Ruta ruta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Posicion pos1 = new Posicion("Sevilla", 1, 2);
        Posicion pos2 = new Posicion("Huelva", 3, 4);
        Posicion pos3 = new Posicion("Cádiz", 5, 6);
        Posicion pos4 = new Posicion("Málaga", 7, 8);
        Posicion pos5 = new Posicion("Córdoba", 9, 10);
        Posicion pos6 = new Posicion("Granada", 11, 12);
        Posicion pos7 = new Posicion("Almería", 13, 14);
        Posicion pos8 = new Posicion("Jaén", 15, 16);

        Tramo tramo1 = new Tramo(1, 1, 2, 2, 3, 3, 4, pos1, pos2);
        Tramo tramo2 = new Tramo(5, 5, 6, 6, 7, 7, 8, pos1, pos4);
        Tramo tramo3 = new Tramo(9, 9, 10, 10, 11, 11, 12, pos4, pos7);

        Ruta ruta1 = new Ruta(1, 3, 5, 7, 9, 11, "Occidental");
        Ruta ruta2 = new Ruta(2, 4, 6, 8, 10, 12, "De la Costa");
        Ruta ruta3 = new Ruta(3, 6, 9, 12, 15, 18, "Mediterranea");


        System.out.println("----- REALDATATIME -----");
        /*
        this.crearPosicionRTD(pos1);
        this.crearPosicionRTD(pos2);
        this.crearPosicionRTD(pos3);
        this.crearPosicionRTD(pos4);
        this.crearPosicionRTD(pos5);
        this.crearPosicionRTD(pos6);
        this.crearPosicionRTD(pos7);
        this.crearPosicionRTD(pos8);

        this.crearTramoRTD(tramo1);
        this.crearTramoRTD(tramo2);
        this.crearTramoRTD(tramo3);

        this.crearRutaRTD(ruta1);
        this.crearRutaRTD(ruta2);
        this.crearRutaRTD(ruta3);

        Posicion posEditRTD = new Posicion("Posicion edit RTD", 7, 7);
        this.editarPosicionRTD("Sevilla", posEditRTD);
        this.verPosicionDescRTD("Posicion edit RTD");
        this.eliminarPosicionRTD("Córdoba");

        Tramo tramoEditRTD = new Tramo(5f, 5f, 5f, 5f, 5f, 5f, 5, pos1, pos4);
        this.editarTramoRTD(4, tramoEditRTD);
        this.verTramoRumboRTD(8);
        this.eliminarTramoRTD(12);

        Ruta rutaEditRTD = new Ruta(9f, 9f, 9f, 9f, 9f, 9f, "Ruta edit RTD");
        this.editarRutaRTD("De la Costa", rutaEditRTD);
        this.verRutaDescRTD("Ruta edit RTD");
        this.eliminarRutaRTD("Occidental");

        this.verPosicionesRTD();
        this.verTramosRTD();
        this.verRutasRTD();
        */

        System.out.println("----- FIRESTORE -----");
/*
        this.crearPosicionFS(pos1);
        this.crearPosicionFS(pos2);
        this.crearPosicionFS(pos3);
        this.crearPosicionFS(pos4);
        this.crearPosicionFS(pos5);
        this.crearPosicionFS(pos6);
        this.crearPosicionFS(pos7);
        this.crearPosicionFS(pos8);

        this.crearTramoFS(tramo1);
        this.crearTramoFS(tramo2);
        this.crearTramoFS(tramo3);

        this.crearRutaFS(ruta1);
        this.crearRutaFS(ruta2);
        this.crearRutaFS(ruta3);
*/
        Posicion posEditFS = new Posicion("Posicion edit FS", 7, 7);
        //this.editarPosicionFS("Sevilla", posEditFS);
        //this.verPosicionDescFS("Posicion edit FS");
        //            this.eliminarPosicionFS("Córdoba");

        Tramo tramoEditFS = new Tramo(5f, 5f, 5f, 5f, 5f, 5f, 5, pos1, pos4);
  //      this.editarTramoFS(4, tramoEditFS);
//        this.verTramoRumboFS(8);
//        this.eliminarTramoFS(2);

        Ruta rutaEditFS = new Ruta(9f, 9f, 9f, 9f, 9f, 9f, "Ruta edit FS");
        this.editarRutaFS("De la Costa", rutaEditFS);
        //this.verRutaDescFS("Occidental");
        //     this.eliminarRutaFS("Occidental");

        /*
        this.verPosicionesFS();
        this.verTramosFS();
        this.verRutasFS();
        */
    }

    private void crearPosicionFS(Posicion posicion) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        posicion.setIdPosicion(UUID.randomUUID().toString());

        Map<String, Object> nueva = new HashMap<>();
        nueva.put("idPosicion", posicion.getIdPosicion());
        nueva.put("latitud", posicion.getLatitud());
        nueva.put("longitud", posicion.getLongitud());
        nueva.put("descripcion", posicion.getDescripcion());

        db.collection("posiciones")
                .document(posicion.getIdPosicion())
                .set(nueva);
    }

    private void crearPosicionRTD(Posicion posicion) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        posicion.setIdPosicion(UUID.randomUUID().toString());
        // myRef.push().setValue(posicion);
        myRef.child("posiciones").child(posicion.getIdPosicion()).setValue(posicion);
        Log.d("/realtimedata", "Posición creada por RealTimeData");
    }

    private void crearRutaFS(Ruta ruta) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        ruta.setIdRuta(UUID.randomUUID().toString());

        Map<String, Object> nueva = new HashMap<>();
        nueva.put("idRuta", ruta.getIdRuta());
        nueva.put("distanciaTeorica", ruta.getDistanciaTeorica());
        nueva.put("distanciaReal", ruta.getDistanciaReal());
        nueva.put("velocidadTeorica", ruta.getVelocidadTeorica());
        nueva.put("velocidadReal", ruta.getVelocidadReal());
        nueva.put("tiempoTeorico", ruta.getTiempoTeorico());
        nueva.put("tiempoReal", ruta.getTiempoReal());
        nueva.put("descripcion", ruta.getDescripcion());

        db.collection("rutas")
                .document(ruta.getIdRuta())
                .set(nueva);

    }

    private void crearRutaRTD(Ruta ruta) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        ruta.setIdRuta(UUID.randomUUID().toString());
        // myRef.push().setValue(ruta);
        myRef.child("rutas").child(ruta.getIdRuta()).setValue(ruta);
        Log.d("/realtimedata", "Ruta creada por RealTimeData");
    }

    private void crearTramoFS(Tramo tramo) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        tramo.setIdTramo(UUID.randomUUID().toString());

        Map<String, Object> nuevo = new HashMap<>();
        nuevo.put("idTramo", tramo.getIdTramo());
        nuevo.put("distanciaTeorica", tramo.getDistanciaTeorica());
        nuevo.put("distanciaReal", tramo.getDistanciaReal());
        nuevo.put("velocidadTeorica", tramo.getVelocidadTeorica());
        nuevo.put("velocidadReal", tramo.getVelocidadReal());
        nuevo.put("tiempoTeorico", tramo.getTiempoTeorico());
        nuevo.put("tiempoReal", tramo.getTiempoReal());
        nuevo.put("rumboTeorico", tramo.getRumboTeorico());
        // TODO Buscar posiciones y añadir al tramo
        nuevo.put("nodoInicial", tramo.getNodoInicial().getIdPosicion());
        nuevo.put("nodoFinal", tramo.getNodoFinal().getIdPosicion());

        db.collection("tramos")
                .document(tramo.getIdTramo())
                .set(nuevo);

    }

    private void crearTramoRTD(Tramo tramo) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        tramo.setIdTramo(UUID.randomUUID().toString());
        // myRef.push().setValue(tramo);
        myRef.child("tramos").child(tramo.getIdTramo()).setValue(tramo);
        Log.d("/realtimedata", "Tramo creado por RealTimeData");
    }

    private void editarPosicionFS(String desc, Posicion posEditFS) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("posiciones")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if (document.getData().get("descripcion").equals(desc)) {
                                    Map<String, Object> edit = new HashMap<>();
                                    posEditFS.setIdPosicion(document.getId());
                                    edit.put("idPosicion", document.getData().get("idPosicion"));
                                    edit.put("latitud", posEditFS.getLatitud());
                                    edit.put("longitud", posEditFS.getLongitud());
                                    edit.put("descripcion", posEditFS.getDescripcion());

                                    db.collection("posiciones")
                                            .document(posEditFS.getIdPosicion())
                                            .set(edit);
                                }
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al editar la posición con la descripción '" + desc + "' en Firestore ");
                        }
                    }
                });
    }

    private void editarPosicionRTD(String desc, Posicion posEditRTD) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("posiciones").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaPosiciones.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Posicion p = obj.getValue(Posicion.class);
                    listaPosiciones.add(p);
                }

                boolean enc = false;
                for (int i = 0; i < listaPosiciones.size() && enc == false; i++) {
                    if (listaPosiciones.get(i).getDescripcion().equals(desc)) {
                        posEditRTD.setIdPosicion(listaPosiciones.get(i).getIdPosicion());
                        myRef.child("posiciones").child(listaPosiciones.get(i).getIdPosicion()).setValue(posEditRTD);
                        enc = true;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al editar la posición con la descripcion '" + desc + "' en RealTimeData", error.toException());
            }
        });
    }

    private void editarRutaFS(String desc, Ruta rutaEditFS) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("rutas")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if (document.getData().get("descripcion").equals(desc)) {
                                    Map<String, Object> edit = new HashMap<>();
                                    rutaEditFS.setIdRuta(document.getId());
                                    edit.put("idRuta", rutaEditFS.getIdRuta());
                                    edit.put("distanciaTeorica", rutaEditFS.getDistanciaTeorica());
                                    edit.put("distanciaReal", rutaEditFS.getDistanciaReal());
                                    edit.put("velocidadTeorica", rutaEditFS.getVelocidadTeorica());
                                    edit.put("velocidadReal", rutaEditFS.getVelocidadReal());
                                    edit.put("tiempoTeorico", rutaEditFS.getTiempoTeorico());
                                    edit.put("tiempoReal", rutaEditFS.getTiempoReal());
                                    edit.put("descripcion", rutaEditFS.getDescripcion());

                                    db.collection("rutas")
                                            .document(rutaEditFS.getIdRuta())
                                            .set(edit);
                                }
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al editar la ruta con la descripción '"+desc+"' en Firestore ");
                        }
                    }
                });
    }

    private void editarRutaRTD(String desc, Ruta rutaEditRTD) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("rutas").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaRutas.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Ruta r = obj.getValue(Ruta.class);
                    listaRutas.add(r);
                }

                boolean enc = false;
                for (int i = 0; i < listaRutas.size() && enc == false; i++) {
                    if (listaRutas.get(i).getDescripcion().equals(desc)) {
                        rutaEditRTD.setIdRuta(listaRutas.get(i).getIdRuta());
                        myRef.child("rutas").child(listaRutas.get(i).getIdRuta()).setValue(rutaEditRTD);
                        enc = true;
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al editar la ruta con la descripción '" + desc + "' en RealTimeData", error.toException());
            }
        });
    }

    // TODO: Arreglar primero ver tramo por rumbo
    private void editarTramoFS(int rumbo, Tramo tramoEditFS) {
    }

    private void editarTramoRTD(int rumbo, Tramo tramoEditRTD) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("tramos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaTramos.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Tramo t = obj.getValue(Tramo.class);
                    listaTramos.add(t);
                }

                boolean enc = false;
                for (int i = 0; i < listaTramos.size() && enc == false; i++) {
                    if (listaTramos.get(i).getRumboTeorico() == rumbo) {
                        tramoEditRTD.setIdTramo(listaTramos.get(i).getIdTramo());
                        myRef.child("tramos").child(listaTramos.get(i).getIdTramo()).setValue(tramoEditRTD);
                        enc = true;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al editar el tramo con el rumbo teórico " + rumbo + " en RealTimeData", error.toException());
            }
        });
    }

    private void eliminarPosicionRTD(String desc) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("posiciones").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaPosiciones.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Posicion p = obj.getValue(Posicion.class);
                    listaPosiciones.add(p);
                }

                boolean enc = false;
                for (int i = 0; i < listaPosiciones.size() && enc == false; i++) {
                    if (listaPosiciones.get(i).getDescripcion().equals(desc)) {
                        myRef.child("posiciones").child(listaPosiciones.get(i).getIdPosicion()).removeValue();
                        enc = true;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al eliminar la posición con la descripción '" + desc + "' en RealTimeData", error.toException());
            }
        });
    }

    private void eliminarRutaRTD(String desc) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("rutas").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaRutas.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Ruta r = obj.getValue(Ruta.class);
                    listaRutas.add(r);
                }

                boolean enc = false;
                for (int i = 0; i < listaRutas.size() && enc == false; i++) {
                    if (listaRutas.get(i).getDescripcion().equals(desc)) {
                        myRef.child("rutas").child(listaRutas.get(i).getIdRuta()).removeValue();
                        enc = true;
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al eliminar la ruta con la descripción '" + desc + "' en RealTimeData", error.toException());
            }
        });
    }

    private void eliminarTramoRTD(int rumbo) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("tramos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaTramos.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Tramo t = obj.getValue(Tramo.class);
                    listaTramos.add(t);
                }

                boolean enc = false;
                for (int i = 0; i < listaTramos.size() && enc == false; i++) {
                    if (listaTramos.get(i).getRumboTeorico() == rumbo) {
                        myRef.child("tramos").child(listaTramos.get(i).getIdTramo()).removeValue();
                        enc = true;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al eliminar el tramo con el rumbo teórico " + rumbo + " en RealTimeData", error.toException());
            }
        });
    }

    private void verPosicionesFS() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("posiciones")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            System.out.println("----- LISTA DE POSICIONES: FIRESTORE -----");
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("/Firestore", "Posición id: " + document.getId() + " => " + document.getData());
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al ver posiciones en Firestore ");
                        }
                    }
                });
    }

    private void verPosicionesRTD() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("posiciones").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaPosiciones.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Posicion p = obj.getValue(Posicion.class);
                    listaPosiciones.add(p);
                }

                for (Posicion pos : listaPosiciones) {
                    System.out.println(pos.toString());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al ver las posiciones en RealTimeData", error.toException());
            }
        });
    }

    private void verPosicionDescFS(String descripcion) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("posiciones")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if (document.getData().get("descripcion").equals(descripcion)) {
                                    Log.d("/Firestore", "Posición id: " + document.getId() + " => " + document.getData());
                                }
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al ver posición con la descripción '" + descripcion + "' en Firestore ");
                        }
                    }
                });
    }

    private void verPosicionDescRTD(String desc) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("posiciones").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaPosiciones.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Posicion p = obj.getValue(Posicion.class);
                    listaPosiciones.add(p);
                }

                boolean enc = false;
                for (int i = 0; i < listaPosiciones.size() && enc == false; i++) {
                    if (listaPosiciones.get(i).getDescripcion().equals(desc)) {
                        System.out.println(listaPosiciones.get(i).toString());
                        enc = true;
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al ver la posición con la descripción '" + desc + "' en RealTimeData", error.toException());
            }
        });
    }

    private void verRutaDescFS(String descripcion) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("rutas")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if (document.getData().get("descripcion").equals(descripcion)) {
                                    Log.d("/Firestore", "Ruta id: " + document.getId() + " => " + document.getData());
                                }
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al ver la ruta con la descripción '" + descripcion + "' en Firestore ");
                        }
                    }
                });
    }

    private void verRutaDescRTD(String desc) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("rutas").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaRutas.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Ruta r = obj.getValue(Ruta.class);
                    listaRutas.add(r);
                }

                boolean enc = false;
                for (int i = 0; i < listaRutas.size() && enc == false; i++) {
                    if (listaRutas.get(i).getDescripcion().equals(desc)) {
                        System.out.println(listaRutas.get(i).toString());
                        enc = true;
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al ver la ruta con la descripción '" + desc + "' en RealTimeData", error.toException());
            }
        });
    }

    private void verRutasFS() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("rutas")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            System.out.println("----- LISTA DE RUTAS: FIRESTORE -----");
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("/Firestore", "Ruta id: " + document.getId() + " => " + document.getData());
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al ver rutas en Firestore ");
                        }
                    }
                });
    }

    private void verRutasRTD() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("rutas").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaRutas.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Ruta r = obj.getValue(Ruta.class);
                    listaRutas.add(r);
                }

                for (Ruta ruta : listaRutas) {
                    System.out.println(ruta.toString());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al ver las rutas en RealTimeData", error.toException());
            }
        });
    }

    private void verTramoRumboFS(int rumbo) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("tramos")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                // TODO: Arreglar la condición del if dentro del for
                                //    if (document.getData().get("rumboTeorico") == rumbo) {
                                Log.d("/Firestore", "Tramo id: " + document.getId() + " => " + document.getData());
                                //    }
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al ver tramos en Firestore ");
                        }
                    }
                });
    }

    private void verTramoRumboRTD(int rumbo) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("tramos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaTramos.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Tramo t = obj.getValue(Tramo.class);
                    listaTramos.add(t);
                }

                boolean enc = false;
                for (int i = 0; i < listaTramos.size() && enc == false; i++) {

                    if (listaTramos.get(i).getRumboTeorico() == rumbo) {
                        System.out.println(listaTramos.get(i).toString());
                        enc = true;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al ver el tramo con el rumbo teórico " + rumbo + " en RealTimeData", error.toException());
            }
        });
    }

    private void verTramosFS() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("tramos")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            System.out.println("----- LISTA DE TRAMOS: FIRESTORE -----");
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("/Firestore", "Tramo id: " + document.getId() + " => " + document.getData());
                            }
                        } else {
                            Log.w("/Firestore-error", "Error al ver tramos en Firestore ");
                        }
                    }
                });
    }

    private void verTramosRTD() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("tramos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaTramos.clear();
                for (DataSnapshot obj : snapshot.getChildren()) {
                    Tramo t = obj.getValue(Tramo.class);
                    listaTramos.add(t);
                }

                for (Tramo tramo : listaTramos) {
                    System.out.println(tramo.toString());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("/realtimedata-error", "Error al ver los tramos en RealTimeData", error.toException());
            }
        });
    }


}