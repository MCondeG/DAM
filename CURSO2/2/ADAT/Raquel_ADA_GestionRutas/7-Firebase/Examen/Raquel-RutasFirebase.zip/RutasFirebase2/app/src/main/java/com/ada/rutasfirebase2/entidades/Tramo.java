package com.ada.rutasfirebase2.entidades;

public class Tramo {

    private String idTramo;
    private float distanciaTeorica;
    private float distanciaReal;
    private float velocidadTeorica;
    private float velocidadReal;
    private float tiempoTeorico;
    private float tiempoReal;
    private int rumboTeorico;
    private Posicion nodoInicial;
    private Posicion nodoFinal;

    public Tramo() {
    }

    public Tramo(float distanciaTeorica, float distanciaReal, float velocidadTeorica, float velocidadReal, float tiempoTeorico, float tiempoReal, int rumboTeorico, Posicion nodoInicial, Posicion nodoFinal) {
        this.distanciaTeorica = distanciaTeorica;
        this.distanciaReal = distanciaReal;
        this.velocidadTeorica = velocidadTeorica;
        this.velocidadReal = velocidadReal;
        this.tiempoTeorico = tiempoTeorico;
        this.tiempoReal = tiempoReal;
        this.rumboTeorico = rumboTeorico;
        this.nodoInicial = nodoInicial;
        this.nodoFinal = nodoFinal;
    }

    public Tramo(String idTramo, float distanciaTeorica, float distanciaReal, float velocidadTeorica, float velocidadReal, float tiempoTeorico, float tiempoReal, int rumboTeorico, Posicion nodoInicial, Posicion nodoFinal) {
        this.idTramo = idTramo;
        this.distanciaTeorica = distanciaTeorica;
        this.distanciaReal = distanciaReal;
        this.velocidadTeorica = velocidadTeorica;
        this.velocidadReal = velocidadReal;
        this.tiempoTeorico = tiempoTeorico;
        this.tiempoReal = tiempoReal;
        this.rumboTeorico = rumboTeorico;
        this.nodoInicial = nodoInicial;
        this.nodoFinal = nodoFinal;
    }

    public String getIdTramo() {
        return idTramo;
    }

    public void setIdTramo(String idTramo) {
        this.idTramo = idTramo;
    }

    public float getDistanciaTeorica() {
        return distanciaTeorica;
    }

    public void setDistanciaTeorica(float distanciaTeorica) {
        this.distanciaTeorica = distanciaTeorica;
    }

    public float getDistanciaReal() {
        return distanciaReal;
    }

    public void setDistanciaReal(float distanciaReal) {
        this.distanciaReal = distanciaReal;
    }

    public float getVelocidadTeorica() {
        return velocidadTeorica;
    }

    public void setVelocidadTeorica(float velocidadTeorica) {
        this.velocidadTeorica = velocidadTeorica;
    }

    public float getVelocidadReal() {
        return velocidadReal;
    }

    public void setVelocidadReal(float velocidadReal) {
        this.velocidadReal = velocidadReal;
    }

    public float getTiempoTeorico() {
        return tiempoTeorico;
    }

    public void setTiempoTeorico(float tiempoTeorico) {
        this.tiempoTeorico = tiempoTeorico;
    }

    public float getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(float tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public int getRumboTeorico() {
        return rumboTeorico;
    }

    public void setRumboTeorico(int rumboTeorico) {
        this.rumboTeorico = rumboTeorico;
    }

    public Posicion getNodoInicial() {
        return nodoInicial;
    }

    public void setNodoInicial(Posicion nodoInicial) {
        this.nodoInicial = nodoInicial;
    }

    public Posicion getNodoFinal() {
        return nodoFinal;
    }

    public void setNodoFinal(Posicion nodoFinal) {
        this.nodoFinal = nodoFinal;
    }

    @Override
    public String toString() {
        return "Tramo{" +
                "idTramo=" + idTramo +
                ", distanciaTeorica=" + distanciaTeorica +
                ", distanciaReal=" + distanciaReal +
                ", velocidadTeorica=" + velocidadTeorica +
                ", velocidadReal=" + velocidadReal +
                ", tiempoTeorico=" + tiempoTeorico +
                ", tiempoReal=" + tiempoReal +
                ", rumboTeorico=" + rumboTeorico +
                ", nodoInicial=" + nodoInicial.getDescripcion() +
                ", nodoFinal=" + nodoFinal.getDescripcion() +
                '}';
    }
}
