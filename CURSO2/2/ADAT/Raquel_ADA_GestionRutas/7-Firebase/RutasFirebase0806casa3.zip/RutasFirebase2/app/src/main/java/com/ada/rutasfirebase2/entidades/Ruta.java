package com.ada.rutasfirebase2.entidades;

public class Ruta {

    private String idRuta;
    private float distanciaTeorica;
    private float distanciaReal;
    private float velocidadTeorica;
    private float velocidadReal;
    private float tiempoTeorico;
    private float tiempoReal;
    private String descripcion;

    public Ruta() {
    }

    public Ruta(float distanciaTeorica, float distanciaReal, float velocidadTeorica, float velocidadReal, float tiempoTeorico, float tiempoReal, String descripcion) {
        this.distanciaTeorica = distanciaTeorica;
        this.distanciaReal = distanciaReal;
        this.velocidadTeorica = velocidadTeorica;
        this.velocidadReal = velocidadReal;
        this.tiempoTeorico = tiempoTeorico;
        this.tiempoReal = tiempoReal;
        this.descripcion = descripcion;
    }

    public Ruta(String idRuta, float distanciaTeorica, float distanciaReal, float velocidadTeorica, float velocidadReal, float tiempoTeorico, float tiempoReal, String descripcion) {
        this.idRuta = idRuta;
        this.distanciaTeorica = distanciaTeorica;
        this.distanciaReal = distanciaReal;
        this.velocidadTeorica = velocidadTeorica;
        this.velocidadReal = velocidadReal;
        this.tiempoTeorico = tiempoTeorico;
        this.tiempoReal = tiempoReal;
        this.descripcion = descripcion;
    }

    public String getIdRuta() {
        return idRuta;
    }

    public void setIdRuta(String idRuta) {
        this.idRuta = idRuta;
    }

    public float getDistanciaTeorica() {
        return distanciaTeorica;
    }

    public void setDistanciaTeorica(float distanciaTeorica) {
        this.distanciaTeorica = distanciaTeorica;
    }

    public float getDistanciaReal() {
        return distanciaReal;
    }

    public void setDistanciaReal(float distanciaReal) {
        this.distanciaReal = distanciaReal;
    }

    public float getVelocidadTeorica() {
        return velocidadTeorica;
    }

    public void setVelocidadTeorica(float velocidadTeorica) {
        this.velocidadTeorica = velocidadTeorica;
    }

    public float getVelocidadReal() {
        return velocidadReal;
    }

    public void setVelocidadReal(float velocidadReal) {
        this.velocidadReal = velocidadReal;
    }

    public float getTiempoTeorico() {
        return tiempoTeorico;
    }

    public void setTiempoTeorico(float tiempoTeorico) {
        this.tiempoTeorico = tiempoTeorico;
    }

    public float getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(float tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Ruta{" +
                "id_ruta=" + idRuta +
                ", distancia teorica=" + distanciaTeorica +
                ", distancia real=" + distanciaReal +
                ", velocidad teorica=" + velocidadTeorica +
                ", velocidad real=" + velocidadReal +
                ", tiempo teorico=" + tiempoTeorico +
                ", tiempo real=" + tiempoReal +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }
}

