/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ada.rutas.rest;

import com.ada.rutas.dto.RutaDTO;
import com.ada.rutas.entities.Ruta;
import com.ada.rutas.services.RutaService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Raquel
 */
@RestController
@CrossOrigin
@RequestMapping("/rutasJson")
public class RutaRest {
    
    private final RutaService rutaService;
    Ruta ruta;
    
    public RutaRest(RutaService rutaService) {
        this.rutaService = rutaService;
    }
    
    @GetMapping
    public ResponseEntity<List<Ruta>> getAll() {
        List<Ruta> rutas = rutaService.verRutas();
        return ResponseEntity.ok(rutas);
    }
    
    @GetMapping("{id_ruta}")
    public ResponseEntity<Ruta> getOne(@PathVariable("id_ruta") Integer id_ruta) {
        List<Ruta> rutas = rutaService.verRutas();
        Ruta ruta = null;
        boolean enc = false;
        for (int i = 0; i < rutas.size() && enc == false; i++) {
            if (id_ruta == rutas.get(i).getIdRuta()) {
                ruta = rutas.get(i);
                enc = true;
            }
        }
        return ResponseEntity.ok(ruta);
    }

    @PostMapping
    public ResponseEntity<Ruta> createRuta(@RequestBody RutaDTO rutaDTO) {
        Ruta ruta = new Ruta();
        ruta.setDistanciaTeorica(rutaDTO.getDistanciaTeorica());
        ruta.setDistanciaReal(rutaDTO.getDistanciaReal());
        ruta.setVelocidadTeorica(rutaDTO.getVelocidadTeorica());
        ruta.setVelocidadReal(rutaDTO.getVelocidadReal());
        ruta.setTiempoTeorico(rutaDTO.getTiempoTeorico());
        ruta.setTiempoReal(rutaDTO.getTiempoReal());
        ruta.setDescripcion(rutaDTO.getDescripcion());
        rutaService.crearRuta(ruta);
        return ResponseEntity.ok(ruta);
    }
    
    @PutMapping("{id_ruta}")
    public ResponseEntity<Ruta> updateRuta(@PathVariable(value = "id_ruta") int id_ruta, @RequestBody RutaDTO rutaDTO) {
        Ruta ruta = rutaService.verRutaId(id_ruta);
        ruta.setDistanciaTeorica(rutaDTO.getDistanciaTeorica());
        ruta.setDistanciaReal(rutaDTO.getDistanciaReal());
        ruta.setVelocidadTeorica(rutaDTO.getVelocidadTeorica());
        ruta.setVelocidadReal(rutaDTO.getVelocidadReal());
        ruta.setTiempoTeorico(rutaDTO.getTiempoTeorico());
        ruta.setTiempoReal(rutaDTO.getTiempoReal());
        ruta.setDescripcion(rutaDTO.getDescripcion());
        rutaService.editarRuta(ruta);
        return ResponseEntity.ok(ruta);
    }
    
    @DeleteMapping("{id_ruta}")
    public ResponseEntity deleteRuta(@PathVariable(value = "id_ruta") int id_ruta) {
        Ruta ruta = rutaService.verRutaId(id_ruta);
        rutaService.borrarRuta(ruta);
        //return ResponseEntity.ok(ruta);
        return ResponseEntity.noContent().build();
    }
}
