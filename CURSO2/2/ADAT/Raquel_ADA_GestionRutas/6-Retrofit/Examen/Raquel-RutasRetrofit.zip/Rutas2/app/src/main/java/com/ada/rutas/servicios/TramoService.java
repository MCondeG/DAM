package com.ada.rutas.servicios;

import com.ada.rutas.dto.TramoDTO;
import com.ada.rutas.pojos.Tramo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface TramoService {

    @GET("/tramosJson")
    Call<List<Tramo>> readTramos();

    @GET("/tramosJson/{id_tramo}")
    Call<Tramo> readTramoId(
            @Path("id_tramo") int id);

    @POST("/tramosJson")
    Call<Tramo> createTramo(
            @Body TramoDTO tramoDTO);

    @PUT("/tramosJson/{id_tramo}")
    Call<Tramo> editTramo(
            @Path("id_tramo") int id_tramo, @Body TramoDTO tramoDTO);

    @DELETE("tramosJson/{id_tramo}")
    Call<Tramo> deleteTramo(
            @Path("id_tramo") int id_tramo);

}
