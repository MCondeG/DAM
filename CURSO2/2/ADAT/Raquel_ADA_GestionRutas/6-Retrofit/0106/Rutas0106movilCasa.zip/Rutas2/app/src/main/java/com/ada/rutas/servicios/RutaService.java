package com.ada.rutas.servicios;

import com.ada.rutas.pojos.Ruta;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RutaService {

    @GET("/rutasJson")
    Call<List<Ruta>> readRutas();

}
