package com.ada.rutas.pojos;

public class Ruta {

    private int idRuta;
    private float distanciaTeorica;
    private float distanciaReal;
    private float velocidadTeorica;
    private float velocidadReal;
    private float tiempoTeorico;
    private float tiempoReal;
    private String descripcion;

    public Ruta() {
    }

    public Ruta(float distanciaTeorica, float distanciaReal, float velocidadTeorica, float velocidadReal, float tiempoTeorico, float tiempoReal, String descripcion) {
        this.distanciaTeorica = distanciaTeorica;
        this.distanciaReal = Ruta.this.distanciaReal;
        this.velocidadTeorica = Ruta.this.velocidadTeorica;
        this.velocidadReal = Ruta.this.velocidadReal;
        this.tiempoTeorico = Ruta.this.tiempoTeorico;
        this.tiempoReal = Ruta.this.tiempoReal;
        this.descripcion = descripcion;
    }

    public Ruta(int idRuta, float distanciaTeorica, float distanciaReal, float velocidadTeorica, float velocidadReal, float tiempoTeorico, float tiempoReal, String descripcion) {
        this.idRuta = idRuta;
        this.distanciaTeorica = distanciaTeorica;
        this.distanciaReal = Ruta.this.distanciaReal;
        this.velocidadTeorica = Ruta.this.velocidadTeorica;
        this.velocidadReal = Ruta.this.velocidadReal;
        this.tiempoTeorico = Ruta.this.tiempoTeorico;
        this.tiempoReal = Ruta.this.tiempoReal;
        this.descripcion = descripcion;
    }

    public int getId_ruta() {
        return idRuta;
    }

    public void setId_ruta(int id_ruta) {
        this.idRuta = idRuta;
    }

    public float getdistanciaTeorica() {
        return distanciaTeorica;
    }

    public void setdistanciaTeorica(float distanciaTeorica) {
        this.distanciaTeorica = distanciaTeorica;
    }

    public float getdistanciaReal() {
        return distanciaReal;
    }

    public void setdistanciaReal(float distanciaReal) {
        this.distanciaReal = Ruta.this.distanciaReal;
    }

    public float getvelocidadTeorica() {
        return velocidadTeorica;
    }

    public void setvelocidadTeorica(float velocidadTeorica) {
        this.velocidadTeorica = Ruta.this.velocidadTeorica;
    }

    public float getvelocidadReal() {
        return velocidadReal;
    }

    public void setvelocidadReal(float velocidadReal) {
        this.velocidadReal = Ruta.this.velocidadReal;
    }

    public float gettiempoTeorico() {
        return tiempoTeorico;
    }

    public void settiempoTeorico(float tiempoTeorico) {
        this.tiempoTeorico = Ruta.this.tiempoTeorico;
    }

    public float gettiempoReal() {
        return tiempoReal;
    }

    public void settiempoReal(float tiempoReal) {
        this.tiempoReal = Ruta.this.tiempoReal;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Ruta{" +
                "id_ruta=" + idRuta +
                ", distancia teorica=" + distanciaTeorica +
                ", distancia real=" + distanciaReal +
                ", velocidad teorica=" + velocidadTeorica +
                ", velocidad real=" + velocidadReal +
                ", tiempo teorico=" + tiempoTeorico +
                ", tiempo real=" + tiempoReal +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }
}

