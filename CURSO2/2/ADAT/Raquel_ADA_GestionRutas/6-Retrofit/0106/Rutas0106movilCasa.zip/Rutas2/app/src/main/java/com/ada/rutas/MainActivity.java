package com.ada.rutas;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.ada.rutas.pojos.Posicion;
import com.ada.rutas.pojos.Ruta;
import com.ada.rutas.pojos.Tramo;
import com.ada.rutas.servicios.PosicionService;
import com.ada.rutas.servicios.RutaService;
import com.ada.rutas.servicios.TramoService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    PosicionService posicionService;
    TramoService tramoService;
    RutaService rutaService;

    List<Posicion> listaPosiciones = new ArrayList<>();
    List<Tramo> listaTramos = new ArrayList<>();
    List<Ruta> listaRutas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("/retrofit", "Rutas con Retrofit");
        setTitle("Rutas con Retrofit");

        Retrofit retrofit = RetrofitCliente.getClient("http://192.168.1.29:9000"); // NO "http://127.0.0.1:9000"
        posicionService = retrofit.create(PosicionService.class);
        tramoService = retrofit.create(TramoService.class);
        rutaService = retrofit.create(RutaService.class);

        verPosiciones();
        verTramos();
        verRutas();

        crearPosicion();

    }

    // TODO
    public void crearPosicion(){

    }

    public void editarPosicion(){

    }

    public void eliminarPosicion(){

    }

    public void verPosiciones() {
        Call<List<Posicion>> callVerPosiciones = posicionService.readPosiciones();

        // FALLA: E//retrofit: ERROR, método verPosiciones(): com.google.gson.stream.MalformedJsonException: Use JsonReader.setLenient(true) to accept malformed JSON at line 1
        // column 182490 path $ // 195178 // 171342
        callVerPosiciones.enqueue(new Callback<List<Posicion>>() {
            @Override
            public void onResponse(Call<List<Posicion>> call, Response<List<Posicion>> response) {
                if (response.isSuccessful()) {
                    // listaPosiciones.clear();
                    listaPosiciones = response.body();
                    Log.d("/retrofit", "----- POSICIONES -----");
                    for (Posicion posicion : listaPosiciones) {
                        Log.d("/retrofit", posicion.toString());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Posicion>> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verPosiciones(): " + t.toString());
            }
        });
    }

    public void verTramos() {
        Call<List<Tramo>> callVerTramos = tramoService.readTramos();
        callVerTramos.enqueue(new Callback<List<Tramo>>() {
            @Override
            public void onResponse(Call<List<Tramo>> call, Response<List<Tramo>> response) {
                if (response.isSuccessful()) {
                    // listaTramos.clear();
                    listaTramos = response.body();
                    Log.d("/retrofit", "----- TRAMOS -----");
                    for (Tramo tramo : listaTramos) {
                        Log.d("/retrofit", tramo.toString());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Tramo>> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verTramos(): " + t.toString());
            }
        });
    }

    public void verRutas() {
        Call<List<Ruta>> callVerRutas = rutaService.readRutas();
        callVerRutas.enqueue(new Callback<List<Ruta>>() {
            @Override
            public void onResponse(Call<List<Ruta>> call, Response<List<Ruta>> response) {
                if (response.isSuccessful()) {
                    // listaRutas.clear();
                    listaRutas = response.body();
                    Log.d("/retrofit", "----- RUTAS -----");
                    for (Ruta ruta : listaRutas) {
                        Log.d("/retrofit", ruta.toString());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Ruta>> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verRutas(): " + t.toString());
            }
        });
    }
}