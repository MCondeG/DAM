package com.ada.rutas.servicios;

import com.ada.rutas.pojos.Tramo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface TramoService {

    @GET("/tramosJson")
    Call<List<Tramo>> readTramos();

}
