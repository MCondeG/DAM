/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ada.rutas.services;

import com.ada.rutas.entities.Posicion;
import com.ada.rutas.repositories.PosicionRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Raquel
 */
@Service
public class PosicionService {

    @Autowired
    private final PosicionRepository posicionRepository;

    public PosicionService(PosicionRepository posicionRepository) {
        this.posicionRepository = posicionRepository;
    }

    // ----- CRUD -----
    public void borrarPosicion(Posicion posicion) {
        posicionRepository.delete(posicion);
    }

    public void crearPosicion(Posicion posicion) {
        posicionRepository.save(posicion);
    }

    public void editarPosicion(Posicion posicion) {
        posicionRepository.save(posicion);
    }

    public List<Posicion> verPosiciones() {
        List<Posicion> posiciones = posicionRepository.findAll();
        return posiciones;
    }

    public Posicion verPosicionesId(Integer idPosicion) {
        Posicion posicion = posicionRepository.getById(idPosicion);
        return posicion;
    }
}
