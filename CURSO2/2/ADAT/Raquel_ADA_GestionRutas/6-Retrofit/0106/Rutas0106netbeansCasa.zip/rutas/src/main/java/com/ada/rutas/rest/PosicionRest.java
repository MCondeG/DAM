/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ada.rutas.rest;

import com.ada.rutas.dto.PosicionDTO;
import com.ada.rutas.entities.Posicion;
import com.ada.rutas.services.PosicionService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Raquel
 */
@RestController
@CrossOrigin
@RequestMapping("/posicionesJson")
public class PosicionRest {

    private final PosicionService posicionService;
    Posicion posicion;

    public PosicionRest(PosicionService posicionService) {
        this.posicionService = posicionService;
    }

    @GetMapping
    public ResponseEntity<List<Posicion>> getAll() {
        List<Posicion> posiciones = posicionService.verPosiciones();
        return ResponseEntity.ok(posiciones);
    }

    /*
    // TODO: Revisar
    @GetMapping
    public ResponseEntity<Posicion> getOne(@PathVariable("id_posicion") int id_posicion) {
        return ResponseEntity.ok(posicionService.verPosicionesId(id_posicion));
    }

    // TODO: Revisar
    @PostMapping
    public ResponseEntity<Posicion> createPosicion(@RequestBody PosicionDTO posicionDTO) {
        Posicion posicion = new Posicion();
        posicion.setLatitud(posicionDTO.getLatitud());
        posicion.setLongitud(posicionDTO.getLongitud());
        posicion.setDescripcion(posicionDTO.getDescripcion());
        // posiciones.add(posicion)
        return ResponseEntity.ok(posicion);
    }

    // TODO: Revisar
    @PutMapping("{id_posicion}")
    public ResponseEntity<Posicion> updatePosicion(@PathVariable("id_posicion") int id_posicion, @RequestBody PosicionDTO posicionDTO) {
        Posicion posicion = posicionService.verPosicionesId(id_posicion);
        posicion.setLatitud(posicionDTO.getLatitud());
        posicion.setLongitud(posicionDTO.getLongitud());
        posicion.setDescripcion(posicionDTO.getDescripcion());
        return ResponseEntity.ok(posicion);
    }

    // TODO: Revisar
    @DeleteMapping("{id_posicion}")
    public ResponseEntity<Posicion> deletePosicion(@PathVariable("id_posicion") int id_posicion) {
        Posicion posicion = posicionService.verPosicionesId(id_posicion);
        // posiciones.remove(posicion);
        return ResponseEntity.ok(posicion);
    }
   */
}
