/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ada.rutas.services;

import com.ada.rutas.entities.Tramo;
import com.ada.rutas.repositories.TramoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Raquel
 */
@Service
public class TramoService {

    @Autowired
    private final TramoRepository tramoRepository;

    public TramoService(TramoRepository tramoRepository) {
        this.tramoRepository = tramoRepository;
    }

    // ----- CRUD -----
    public void borrarTramo(Tramo tramo) {
        tramoRepository.delete(tramo);
    }

    public void crearTramo(Tramo tramo) {
        tramoRepository.save(tramo);
    }

    public void editarTramo(Tramo tramo) {
        tramoRepository.save(tramo);
    }

    public List<Tramo> verTramos() {
        return tramoRepository.findAll();
    }

    public Tramo verTramoId(Integer id_tramo) {
        return tramoRepository.getById(id_tramo);
    }

}
