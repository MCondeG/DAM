/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ada.rutas.controllers;

import com.ada.rutas.entities.Posicion;
import com.ada.rutas.entities.Ruta;
import com.ada.rutas.entities.Tramo;
import com.ada.rutas.services.PosicionService;
import com.ada.rutas.services.RutaService;
import com.ada.rutas.services.TramoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Raquel
 */
@Controller
public class InicioController {

    @Autowired
    private final PosicionService posicionService;

    @Autowired
    private final TramoService tramoService;

    @Autowired
    private final RutaService rutaService;

    public InicioController(PosicionService posicionService, TramoService tramoService, RutaService rutaService) {
        super();
        this.posicionService = posicionService;
        this.tramoService = tramoService;
        this.rutaService = rutaService;
    }

    @RequestMapping("/")
    public String inicio() {
        return "inicio";
    }
    
    @RequestMapping("/posiciones")
    public String posiciones() {
        return "t_posiciones";
    }
    
    @RequestMapping("/tramos")
    public String tramos() {
        return "t_tramos";
    }

    @RequestMapping("/rutas")
    public String rutas() {
        return "t_rutas";
    }

    // POSICIÓN
    @RequestMapping("/ver_posiciones")
    public String verPosiciones(Model modelo) {
        List<Posicion> posiciones = posicionService.verPosiciones();
        modelo.addAttribute("posiciones", posiciones);
        return "ver_posiciones";
    }

    @RequestMapping("/borrar_posicion/{id_posicion}")
    public String borrarPosicion(@PathVariable(value = "id_posicion") Integer id_posicion) {
        Posicion posicion = posicionService.verPosicionId(id_posicion);
        posicionService.borrarPosicion(posicion);
        return "redirect:/ver_posiciones";
    }

    @RequestMapping("/nueva_posicion")
    public String crearPosicion(Model modelo) {
        Posicion posicion = new Posicion();
        modelo.addAttribute("posicion", posicion);
        return "crear_posicion";
    }

    @RequestMapping("/editar_posicion/{id_posicion}")
    public String editarPosicion(@PathVariable(value = "id_posicion") Integer id_posicion, Model modelo) {
        Posicion posicion = posicionService.verPosicionId(id_posicion);
        modelo.addAttribute("posicion", posicion);
        return "actualizar_posicion";
    }

    @RequestMapping("/guardar_posicion")
    public String guardarPosicion(Posicion posicion) {
        posicionService.crearPosicion(posicion);
        return "redirect:/ver_posiciones";
    }

    // TRAMO
    @RequestMapping("/ver_tramos")
    public String verTramos(Model modelo) {
        List<Tramo> tramos = tramoService.verTramos();
        modelo.addAttribute("tramos", tramos);
        return "ver_tramos";
    }

    @RequestMapping("/borrar_tramo/{id_tramo}")
    public String borrarTramo(@PathVariable(value = "id_tramo") Integer id_tramo) {
        Tramo tramo = tramoService.verTramoId(id_tramo);
        tramoService.borrarTramo(tramo);
        return "redirect:/ver_tramos";
    }

    @RequestMapping("/nuevo_tramo")
    public String crearTramo(Model modelo) {
        Tramo tramo = new Tramo();
        List<Posicion> posiciones = posicionService.verPosiciones();

        modelo.addAttribute("tramo", tramo);
        modelo.addAttribute("posiciones", posiciones);
        return "crear_tramo";
    }

    @RequestMapping("/editar_tramo/{id_tramo}")
    public String editarTramo(@PathVariable(value = "id_tramo") Integer id_tramo, Model modelo) {
        Tramo tramo = tramoService.verTramoId(id_tramo);
        List<Posicion> posiciones = posicionService.verPosiciones();

        modelo.addAttribute("posiciones", posiciones);
        modelo.addAttribute("tramo", tramo);
        return "actualizar_tramo";
    }

    @RequestMapping("/guardar_tramo")
    public String guardarTramo(Tramo tramo) {
        tramoService.crearTramo(tramo);
        return "redirect:/ver_tramos";
    }

    // RUTA
    @RequestMapping("/ver_rutas")
    public String verRutas(Model modelo) {
        List<Ruta> rutas = rutaService.verRutas();
        modelo.addAttribute("rutas", rutas);
        return "ver_rutas";
    }

    @RequestMapping("/borrar_ruta/{id_ruta}")
    public String borrarRuta(@PathVariable(value = "id_ruta") Integer id_ruta) {
        Ruta ruta = rutaService.verRutaId(id_ruta);
        rutaService.borrarRuta(ruta);
        return "redirect:/ver_rutas";
    }

    @RequestMapping("/nueva_ruta")
    public String crearRuta(Model modelo) {
        Ruta ruta = new Ruta();
        List<Tramo> tramos = tramoService.verTramos();
        modelo.addAttribute("tramos", tramos);
        modelo.addAttribute("ruta", ruta);
        return "crear_ruta";
    }

    @RequestMapping("/editar_ruta/{id_ruta}")
    public String editarRuta(@PathVariable(value = "id_ruta") Integer id_ruta, Model modelo) {
        Ruta ruta = rutaService.verRutaId(id_ruta);
        List<Tramo> tramos = tramoService.verTramos();
        modelo.addAttribute("tramos", tramos);
        modelo.addAttribute("ruta", ruta);
        return "actualizar_ruta";
    }

    @RequestMapping("/guardar_ruta")
    public String guardarRuta(Ruta ruta) {
        rutaService.crearRuta(ruta);
        return "redirect:/ver_rutas";
    }
}
