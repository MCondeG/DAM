/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ada.rutas.dto;

import com.ada.rutas.entities.Posicion;

/**
 *
 * @author Raquel
 */
public class TramoDTO {

    private float distanciaTeorica;
    private float distanciaReal;
    private float velocidadTeorica;
    private float velocidadReal;
    private float tiempoTeorico;
    private float tiempoReal;
    private int rumboTeorico;
    private Posicion nodoInicial;
    private Posicion nodoFinal;

    public TramoDTO() {
    }

    public float getDistanciaTeorica() {
        return distanciaTeorica;
    }

    public void setDistanciaTeorica(float distanciaTeorica) {
        this.distanciaTeorica = distanciaTeorica;
    }

    public float getDistanciaReal() {
        return distanciaReal;
    }

    public void setDistanciaReal(float distanciaReal) {
        this.distanciaReal = distanciaReal;
    }

    public float getVelocidadTeorica() {
        return velocidadTeorica;
    }

    public void setVelocidadTeorica(float velocidadTeorica) {
        this.velocidadTeorica = velocidadTeorica;
    }

    public float getVelocidadReal() {
        return velocidadReal;
    }

    public void setVelocidadReal(float velocidadReal) {
        this.velocidadReal = velocidadReal;
    }

    public float getTiempoTeorico() {
        return tiempoTeorico;
    }

    public void setTiempoTeorico(float tiempoTeorico) {
        this.tiempoTeorico = tiempoTeorico;
    }

    public float getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(float tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public int getRumboTeorico() {
        return rumboTeorico;
    }

    public void setRumboTeorico(int rumboTeorico) {
        this.rumboTeorico = rumboTeorico;
    }

    public Posicion getNodoInicial() {
        return nodoInicial;
    }

    public void setNodoInicial(Posicion nodoInicial) {
        this.nodoInicial = nodoInicial;
    }

    public Posicion getNodoFinal() {
        return nodoFinal;
    }

    public void setNodoFinal(Posicion nodoFinal) {
        this.nodoFinal = nodoFinal;
    }

}
