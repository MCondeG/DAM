/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ada.rutas.rest;

import com.ada.rutas.dto.TramoDTO;
import com.ada.rutas.entities.Tramo;
import com.ada.rutas.services.TramoService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Raquel
 */
@RestController
@CrossOrigin
@RequestMapping("/tramosJson")
public class TramoRest {

    private final TramoService tramoService;
    Tramo tramo;

    public TramoRest(TramoService posicionService) {
        this.tramoService = posicionService;
    }

    @GetMapping
    public ResponseEntity<List<Tramo>> getAll() {
        List<Tramo> tramos = tramoService.verTramos();
        return ResponseEntity.ok(tramos);
    }

    @GetMapping("{id_tramo}")
    public ResponseEntity<Tramo> getOne(@PathVariable("id_tramo") Integer id_tramo) {
        List<Tramo> tramos = tramoService.verTramos();
        Tramo tramo = null;
        boolean enc = false;
        for (int i = 0; i < tramos.size() && enc == false; i++) {
            if (id_tramo == tramos.get(i).getIdTramo()) {
                tramo = tramos.get(i);
                enc = true;
            }
        }
        return ResponseEntity.ok(tramo);
    }

    // TODO: Revisar funcionamiento
    @PostMapping
    public ResponseEntity<Tramo> createTramo(@RequestBody Tramo tramo) {
        tramoService.crearTramo(tramo);
        return ResponseEntity.ok(tramo);
    }

    // TODO: Revisar funcionamiento
    @PutMapping("{id_tramo}")
    public ResponseEntity<Tramo> updateTramo(@PathVariable(value = "id_tramo") int id_tramo, @RequestBody TramoDTO tramoDTO) {
        Tramo tramo = tramoService.verTramoId(id_tramo);
        tramo.setDistanciaTeorica(tramoDTO.getDistanciaTeorica());
        tramo.setDistanciaReal(tramoDTO.getDistanciaReal());
        tramo.setVelocidadTeorica(tramoDTO.getVelocidadTeorica());
        tramo.setVelocidadReal(tramoDTO.getVelocidadReal());
        tramo.setTiempoTeorico(tramoDTO.getTiempoTeorico());
        tramo.setTiempoReal(tramoDTO.getTiempoReal());
        tramo.setRumboTeorico(tramoDTO.getRumboTeorico());
        tramo.setNodoInicial(tramoDTO.getNodoInicial());
        tramo.setNodoFinal(tramoDTO.getNodoFinal());
        tramoService.editarTramo(tramo);
        return ResponseEntity.ok(tramo);
    }

    @DeleteMapping("{id_tramo}")
    public ResponseEntity deleteTramo(@PathVariable(value = "id_tramo") int id_tramo) {
        Tramo tramo = tramoService.verTramoId(id_tramo);
        tramoService.borrarTramo(tramo);
        //return ResponseEntity.ok(tramo);
        return ResponseEntity.noContent().build();
    }
}
