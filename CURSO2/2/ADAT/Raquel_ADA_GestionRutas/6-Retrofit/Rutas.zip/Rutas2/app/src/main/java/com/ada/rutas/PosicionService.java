package com.ada.rutas;

import com.ada.rutas.pojos.Posicion;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface PosicionService {

    @GET("/ver_posiciones/")
    Call<List<Posicion>> readPosiciones();

    @POST("/nueva_posicion/")
    Call<Posicion> createPosicion(
            @Body Posicion posicion);

    @PUT("/editar_posicion/{id_posicion}")
    Call<Posicion> editPosicion(
            @Path("id_posicion") int id_posicion, @Body Posicion posicion);

    @DELETE("/borrar_posicion/{id_posicion}")
    Call<Posicion> deletePosicion(
            @Query("id_posicion") int id_posicion);

}