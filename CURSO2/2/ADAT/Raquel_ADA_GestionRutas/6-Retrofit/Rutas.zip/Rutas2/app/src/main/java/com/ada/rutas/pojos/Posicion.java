package com.ada.rutas.pojos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Posicion {

    private int id_posicion;
    private String descripcion;
    private float latitud;
    private float longitud;

    public Posicion() {
    }

    public Posicion(String descripcion, float latitud, float longitud) {
        this.descripcion = descripcion;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public Posicion(int id_posicion, String descripcion, float latitud, float longitud) {
        this.id_posicion = id_posicion;
        this.descripcion = descripcion;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public int getId_posicion() {
        return id_posicion;
    }

    public void setId_posicion(int id_posicion) {
        this.id_posicion = id_posicion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getLatitud() {
        return latitud;
    }

    public void setLatitud(float latitud) {
        this.latitud = latitud;
    }

    public float getLongitud() {
        return longitud;
    }

    public void setLongitud(float longitud) {
        this.longitud = longitud;
    }
}

