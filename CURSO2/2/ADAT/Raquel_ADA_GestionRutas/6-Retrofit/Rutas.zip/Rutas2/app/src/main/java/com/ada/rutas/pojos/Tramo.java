package com.ada.rutas.pojos;

public class Tramo {
}
