package com.ada.rutas;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.ada.rutas.pojos.Posicion;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    List<Posicion> listaPosiciones = new ArrayList<>();
    PosicionService posicionService;

    // public static final String API_URL = "http://192.168.1.29:9000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("/retrofit", "Rutas con Retrofit");
        setTitle("Rutas con Retrofit");

        Retrofit retrofit = RetrofitCliente.getClient("http://127.0.0.1:9000");
        posicionService = retrofit.create(PosicionService.class);

        verPosiciones();

    }


    public void verPosiciones() {
        Call<List<Posicion>> call = posicionService.readPosiciones();

        call.enqueue(new Callback<List<Posicion>>() { // FALLA: E//retrofit: ERROR, método verPosiciones(): java.net.ConnectException: Failed to connect to /127.0.0.1:9000
            @Override
            public void onResponse(Call<List<Posicion>> call, Response<List<Posicion>> response) {
                if (response.isSuccessful()) {
                    // listaPosiciones.clear();
                    listaPosiciones = response.body();
                    for (Posicion posicion : listaPosiciones) {
                        Log.d("/retrofit", "posiciones.descripcion");
                        Log.d("/retrofit", posicion.getDescripcion());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Posicion>> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verPosiciones(): " + t.toString());
            }
        });
    }

}