package com.ada.rutas.dto;

public class RutaDTO {

    private float distanciaTeorica;
    private float distanciaReal;
    private float velocidadTeorica;
    private float velocidadReal;
    private float tiempoTeorico;
    private float tiempoReal;
    private String descripcion;

    public RutaDTO() {
    }

    public float getDistanciaTeorica() {
        return distanciaTeorica;
    }

    public void setDistanciaTeorica(float distanciaTeorica) {
        this.distanciaTeorica = distanciaTeorica;
    }

    public float getDistanciaReal() {
        return distanciaReal;
    }

    public void setDistanciaReal(float distanciaReal) {
        this.distanciaReal = distanciaReal;
    }

    public float getVelocidadTeorica() {
        return velocidadTeorica;
    }

    public void setVelocidadTeorica(float velocidadTeorica) {
        this.velocidadTeorica = velocidadTeorica;
    }

    public float getVelocidadReal() {
        return velocidadReal;
    }

    public void setVelocidadReal(float velocidadReal) {
        this.velocidadReal = velocidadReal;
    }

    public float getTiempoTeorico() {
        return tiempoTeorico;
    }

    public void setTiempoTeorico(float tiempoTeorico) {
        this.tiempoTeorico = tiempoTeorico;
    }

    public float getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(float tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

}
