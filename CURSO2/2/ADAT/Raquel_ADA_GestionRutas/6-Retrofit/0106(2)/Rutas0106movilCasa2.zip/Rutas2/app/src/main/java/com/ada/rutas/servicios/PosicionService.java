package com.ada.rutas.servicios;

import com.ada.rutas.dto.PosicionDTO;
import com.ada.rutas.pojos.Posicion;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface PosicionService {

    @GET("/posicionesJson")
    Call<List<Posicion>> readPosiciones();

    @GET("/posicionesJson/{id_posicion}")
    Call<Posicion> readPosicionId(
            @Path("id_posicion") int id);

    @POST("/posicionesJson")
    Call<Posicion> createPosicion(
            @Body PosicionDTO posicionDTO);

    @PUT("/posicionesJson/{id_posicion}")
    Call<Posicion> editPosicion(
            @Path("id_posicion") int id_posicion, @Body PosicionDTO posicionDTO);

    @DELETE("posicionesJson/{id_posicion}")
    Call<Posicion> deletePosicion(
            @Path("id_posicion") int id_posicion);

}