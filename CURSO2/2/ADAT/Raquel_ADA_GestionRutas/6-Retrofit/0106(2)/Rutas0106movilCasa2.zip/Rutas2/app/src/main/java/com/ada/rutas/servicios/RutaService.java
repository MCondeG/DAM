package com.ada.rutas.servicios;

import com.ada.rutas.dto.RutaDTO;
import com.ada.rutas.pojos.Ruta;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RutaService {

    @GET("/rutasJson")
    Call<List<Ruta>> readRutas();

    @GET("/rutasJson/{id_ruta}")
    Call<Ruta> readRutaId(
            @Path("id_ruta") int id);

    @POST("/rutasJson")
    Call<Ruta> createRuta(
            @Body RutaDTO rutaDTO);

    @PUT("/rutasJson/{id_ruta}")
    Call<Ruta> editRuta(
            @Path("id_ruta") int id_ruta, @Body RutaDTO rutaDTO);

    @DELETE("rutasJson/{id_ruta}")
    Call<Ruta> deleteRuta(
            @Path("id_ruta") int id_ruta);

}
