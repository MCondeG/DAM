package com.ada.rutas;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.ada.rutas.dto.PosicionDTO;
import com.ada.rutas.dto.RutaDTO;
import com.ada.rutas.dto.TramoDTO;
import com.ada.rutas.pojos.Posicion;
import com.ada.rutas.pojos.Ruta;
import com.ada.rutas.pojos.Tramo;
import com.ada.rutas.servicios.PosicionService;
import com.ada.rutas.servicios.RutaService;
import com.ada.rutas.servicios.TramoService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    PosicionService posicionService;
    TramoService tramoService;
    RutaService rutaService;

    List<Posicion> listaPosiciones = new ArrayList<>();
    List<Tramo> listaTramos = new ArrayList<>();
    List<Ruta> listaRutas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("/retrofit", "Rutas con Retrofit");
        setTitle("Rutas con Retrofit");

        Retrofit retrofit = RetrofitCliente.getClient("http://192.168.1.29:9000"); // NO "http://127.0.0.1:9000"
        posicionService = retrofit.create(PosicionService.class);
        tramoService = retrofit.create(TramoService.class);
        rutaService = retrofit.create(RutaService.class);
/*
        // CREAR
        PosicionDTO posicionDTO = new PosicionDTO();
        posicionDTO.setDescripcion("prueba crear pos Retrofit");
        posicionDTO.setLatitud(1);
        posicionDTO.setLongitud(1);
        PosicionDTO posicionDTO2 = new PosicionDTO();
        posicionDTO2.setDescripcion("prueba crear pos Retrofit2");
        posicionDTO2.setLatitud(2);
        posicionDTO2.setLongitud(2);
        crearPosicion(posicionDTO);
        crearPosicion(posicionDTO2);

        TramoDTO tramoDTO = new TramoDTO();
        tramoDTO.setDistanciaReal(1);
        tramoDTO.setDistanciaTeorica(1);
        tramoDTO.setTiempoReal(2);
        tramoDTO.setTiempoTeorico(2);
        tramoDTO.setVelocidadReal(3);
        tramoDTO.setVelocidadTeorica(3);
        tramoDTO.setRumboTeorico(4);
        Posicion posIni = new Posicion();
        Posicion posFin = new Posicion();
        posIni.setIdPosicion(1);
        posFin.setIdPosicion(8);
        tramoDTO.setNodoInicial(posIni);
        tramoDTO.setNodoFinal(posFin);
        crearTramo(tramoDTO);

        RutaDTO rutaDTO = new RutaDTO();
        rutaDTO.setDistanciaReal(1);
        rutaDTO.setDistanciaTeorica(1);
        rutaDTO.setTiempoReal(2);
        rutaDTO.setTiempoTeorico(2);
        rutaDTO.setVelocidadReal(3);
        rutaDTO.setVelocidadTeorica(3);
        rutaDTO.setDescripcion("Prueba crear ruta Retrofit");
        crearRuta(rutaDTO);
*/
        // ELIMINAR
       // eliminarRuta(7);
        // eliminarTramo(5);
        eliminarPosicion(15);
/*
        // EDITAR
        Posicion posicion = new Posicion();
        posicion.setIdPosicion(2);
        posicion.setLatitud(8);
        posicion.setLongitud(16);
        posicion.setDescripcion("Probando editar pos retrofit");
        editarPosicion( posicion);

        Tramo tramo = new Tramo();
        tramo.setIdTramo(2);
        tramo.setDistanciaReal(1);
        tramo.setDistanciaTeorica(1);
        tramo.setTiempoReal(2);
        tramo.setTiempoTeorico(2);
        tramo.setVelocidadReal(3);
        tramo.setVelocidadTeorica(3);
        tramo.setRumboTeorico(4);
        Posicion posEdIni = new Posicion();
        Posicion posEdFin = new Posicion();
        posIni.setIdPosicion(1);
        posFin.setIdPosicion(8);
        tramo.setNodoInicial(posEdIni);
        tramo.setNodoFinal(posEdFin);
        editarTramo(tramo);

        Ruta ruta = new Ruta();
        ruta.setIdRuta(2);
        ruta.setDistanciaReal(1);
        ruta.setDistanciaTeorica(1);
        ruta.setTiempoReal(2);
        ruta.setTiempoTeorico(2);
        ruta.setVelocidadReal(3);
        ruta.setVelocidadTeorica(3);
        ruta.setDescripcion("Prueba crear ruta Retrofit");

        // VER POR ID
        verPosicionID(4);
        verTramoID(2);
        verRutaID(8);

        // VER COMPLETO
        verPosiciones();
        verTramos();
        verRutas();
*/
    }


    // TODO
    public void crearPosicion(PosicionDTO posicionDTO) {
        Call<Posicion> callCrearPosicion = posicionService.createPosicion(posicionDTO);
        callCrearPosicion.enqueue(new Callback<Posicion>() {
            @Override
            public void onResponse(Call<Posicion> call, Response<Posicion> response) {
                if (response.isSuccessful()) {
                    Posicion nueva = response.body();
                    Log.d("/retrofit", "Posicion creada");
                }
            }

            @Override
            public void onFailure(Call<Posicion> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método crearPosicion(): " + t.toString());
            }
        });
    }

    // TODO
    public void editarPosicion(Posicion posicion) {

    }

    // TODO
    public void eliminarPosicion(int id) {
        Call<Posicion> callEliminarPosicion = posicionService.deletePosicion(id);
        callEliminarPosicion.enqueue(new Callback<Posicion>() {
            @Override
            public void onResponse(Call<Posicion> call, Response<Posicion> response) {
                if (response.isSuccessful()){
                    Posicion posicion = response.body();
                }
            }

            @Override
            public void onFailure(Call<Posicion> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método eliminarPosicion(): " + t.toString());
            }
        });
    }

    public void verPosiciones() {
        Call<List<Posicion>> callVerPosiciones = posicionService.readPosiciones();
        callVerPosiciones.enqueue(new Callback<List<Posicion>>() {
            @Override
            public void onResponse(Call<List<Posicion>> call, Response<List<Posicion>> response) {
                if (response.isSuccessful()) {
                    // listaPosiciones.clear();
                    listaPosiciones = response.body();
                    Log.d("/retrofit", "----- POSICIONES -----");
                    for (Posicion posicion : listaPosiciones) {
                        Log.d("/retrofit", posicion.toString());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Posicion>> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verPosiciones(): " + t.toString());
            }
        });
    }

    public void verPosicionID(int id) {
        Call<Posicion> callVerPosicionId = posicionService.readPosicionId(id);
        callVerPosicionId.enqueue(new Callback<Posicion>() {
            @Override
            public void onResponse(Call<Posicion> call, Response<Posicion> response) {
                if (response.isSuccessful()) {
                    Posicion posicion = response.body();
                    Log.d("/retrofit", "----- POSICIÓN CON ID: " + id + " -----");
                    Log.d("/retrofit", posicion.toString());
                }
            }

            @Override
            public void onFailure(Call<Posicion> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verPosicionID(int id): " + t.toString());
            }
        });
    }


    // TODO
    public void crearTramo(TramoDTO tramoDTO) {
        Call<Tramo> callCrearTramo = tramoService.createTramo(tramoDTO);
        callCrearTramo.enqueue(new Callback<Tramo>() {
            @Override
            public void onResponse(Call<Tramo> call, Response<Tramo> response) {
                if (response.isSuccessful()) {
                    Tramo tramo = response.body();
                    Log.d("/retrofit", "Tramo creado");
                }
            }

            @Override
            public void onFailure(Call<Tramo> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método crearTramo(): " + t.toString());
            }
        });
    }

    // TODO
    public void editarTramo(Tramo tramo) {

    }

    public void eliminarTramo(int id) {
        Call<Tramo> callEliminarTramo = tramoService.deleteTramo(id);
        callEliminarTramo.enqueue(new Callback<Tramo>() {
            @Override
            public void onResponse(Call<Tramo> call, Response<Tramo> response) {
                if (response.isSuccessful()){
                    Tramo tramo = response.body();
                }
            }

            @Override
            public void onFailure(Call<Tramo> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método eliminarTramo(): " + t.toString());
            }
        });
    }

    public void verTramos() {
        Call<List<Tramo>> callVerTramos = tramoService.readTramos();
        callVerTramos.enqueue(new Callback<List<Tramo>>() {
            @Override
            public void onResponse(Call<List<Tramo>> call, Response<List<Tramo>> response) {
                if (response.isSuccessful()) {
                    // listaTramos.clear();
                    listaTramos = response.body();
                    Log.d("/retrofit", "----- TRAMOS -----");
                    for (Tramo tramo : listaTramos) {
                        Log.d("/retrofit", tramo.toString());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Tramo>> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verTramos(): " + t.toString());
            }
        });
    }

    public void verTramoID(int id) {
        Call<Tramo> callVerTramoId = tramoService.readTramoId(id);
        callVerTramoId.enqueue(new Callback<Tramo>() {
            @Override
            public void onResponse(Call<Tramo> call, Response<Tramo> response) {
                if (response.isSuccessful()) {
                    Tramo tramo = response.body();
                    Log.d("/retrofit", "----- TRAMO CON ID: " + id + " -----");
                    Log.d("/retrofit", tramo.toString());
                }
            }

            @Override
            public void onFailure(Call<Tramo> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verTramoID(int id): " + t.toString());
            }
        });
    }


    // TODO
    public void crearRuta(RutaDTO rutaDTO) {
        Call<Ruta> callCrearRuta = rutaService.createRuta(rutaDTO);
        callCrearRuta.enqueue(new Callback<Ruta>() {
            @Override
            public void onResponse(Call<Ruta> call, Response<Ruta> response) {
                if (response.isSuccessful()) {
                    Ruta ruta = response.body();
                    Log.d("/retrofit", "Ruta creada");
                }
            }

            @Override
            public void onFailure(Call<Ruta> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método crearRuta(): " + t.toString());
            }
        });
    }

    // TODO
    public void editarRuta() {

    }

    public void eliminarRuta(int id) {
        Call<Ruta> callEliminarRuta = rutaService.deleteRuta(id);
        callEliminarRuta.enqueue(new Callback<Ruta>() {
            @Override
            public void onResponse(Call<Ruta> call, Response<Ruta> response) {
                if (response.isSuccessful()){
                    Ruta ruta = response.body();
                }
            }

            @Override
            public void onFailure(Call<Ruta> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método eliminarRuta(): " + t.toString());
            }
        });
    }

    public void verRutas() {
        Call<List<Ruta>> callVerRutas = rutaService.readRutas();
        callVerRutas.enqueue(new Callback<List<Ruta>>() {
            @Override
            public void onResponse(Call<List<Ruta>> call, Response<List<Ruta>> response) {
                if (response.isSuccessful()) {
                    // listaRutas.clear();
                    listaRutas = response.body();
                    Log.d("/retrofit", "----- RUTAS -----");
                    for (Ruta ruta : listaRutas) {
                        Log.d("/retrofit", ruta.toString());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Ruta>> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verRutas(): " + t.toString());
            }
        });
    }

    public void verRutaID(int id) {
        Call<Ruta> callVerRutaId = rutaService.readRutaId(id);
        callVerRutaId.enqueue(new Callback<Ruta>() {
            @Override
            public void onResponse(Call<Ruta> call, Response<Ruta> response) {
                if (response.isSuccessful()) {
                    Ruta ruta = response.body();
                    Log.d("/retrofit", "----- RUTA CON ID: " + id + " -----");
                    Log.d("/retrofit", ruta.toString());
                }
            }

            @Override
            public void onFailure(Call<Ruta> call, Throwable t) {
                Log.e("/retrofit", "ERROR, método verRutaID(int id): " + t.toString());
            }
        });
    }
}