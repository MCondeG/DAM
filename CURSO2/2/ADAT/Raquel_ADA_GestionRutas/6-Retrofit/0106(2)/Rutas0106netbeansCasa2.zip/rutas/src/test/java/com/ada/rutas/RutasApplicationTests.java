package com.ada.rutas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RutasApplicationTests {

	@Test
	void contextLoads() {
	}

}
