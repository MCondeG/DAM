/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ada.rutas.services;

import com.ada.rutas.entities.Ruta;
import com.ada.rutas.repositories.RutaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Raquel
 */
@Service
public class RutaService {

    @Autowired
    private final RutaRepository rutaRepository;

    public RutaService(RutaRepository rutaRepository) {
        this.rutaRepository = rutaRepository;
    }

    // ----- CRUD -----
    public void borrarRuta(Ruta ruta) {
        rutaRepository.delete(ruta);
    }

    public void crearRuta(Ruta ruta) {
        rutaRepository.save(ruta);
    }

    public void editarRuta(Ruta ruta) {
        rutaRepository.save(ruta);
    }

    public List<Ruta> verRutas() {
        return rutaRepository.findAll();
    }

    public Ruta verRutaId(Integer id_ruta) {
        return rutaRepository.getById(id_ruta);
    }

}
