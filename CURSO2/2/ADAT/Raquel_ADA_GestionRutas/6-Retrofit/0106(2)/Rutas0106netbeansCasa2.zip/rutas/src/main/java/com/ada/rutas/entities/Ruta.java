/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ada.rutas.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Raquel
 */
@Entity
@Table(name = "ruta")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ruta.findAll", query = "SELECT r FROM Ruta r"),
    @NamedQuery(name = "Ruta.findByIdRuta", query = "SELECT r FROM Ruta r WHERE r.idRuta = :idRuta"),
    @NamedQuery(name = "Ruta.findByDistanciaTeorica", query = "SELECT r FROM Ruta r WHERE r.distanciaTeorica = :distanciaTeorica"),
    @NamedQuery(name = "Ruta.findByVelocidadTeorica", query = "SELECT r FROM Ruta r WHERE r.velocidadTeorica = :velocidadTeorica"),
    @NamedQuery(name = "Ruta.findByTiempoTeorico", query = "SELECT r FROM Ruta r WHERE r.tiempoTeorico = :tiempoTeorico"),
    @NamedQuery(name = "Ruta.findByDistanciaReal", query = "SELECT r FROM Ruta r WHERE r.distanciaReal = :distanciaReal"),
    @NamedQuery(name = "Ruta.findByVelocidadReal", query = "SELECT r FROM Ruta r WHERE r.velocidadReal = :velocidadReal"),
    @NamedQuery(name = "Ruta.findByTiempoReal", query = "SELECT r FROM Ruta r WHERE r.tiempoReal = :tiempoReal"),
    @NamedQuery(name = "Ruta.findByDescripcion", query = "SELECT r FROM Ruta r WHERE r.descripcion = :descripcion")})
public class Ruta implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_ruta")
    private Integer idRuta;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "distancia_teorica")
    private Float distanciaTeorica;
    @Column(name = "velocidad_teorica")
    private Float velocidadTeorica;
    @Column(name = "tiempo_teorico")
    private Float tiempoTeorico;
    @Column(name = "distancia_real")
    private Float distanciaReal;
    @Column(name = "velocidad_real")
    private Float velocidadReal;
    @Column(name = "tiempo_real")
    private Float tiempoReal;
    @Column(name = "descripcion")
    private String descripcion;
    @JoinTable(name = "tramo_has_ruta", joinColumns = {
        @JoinColumn(name = "ruta_id_ruta", referencedColumnName = "id_ruta")}, inverseJoinColumns = {
        @JoinColumn(name = "tramo_id_tramo", referencedColumnName = "id_tramo")})
    @ManyToMany
    private List<Tramo> tramoList;

    public Ruta() {
    }

    public Ruta(Integer idRuta) {
        this.idRuta = idRuta;
    }

    public Integer getIdRuta() {
        return idRuta;
    }

    public void setIdRuta(Integer idRuta) {
        this.idRuta = idRuta;
    }

    public Float getDistanciaTeorica() {
        return distanciaTeorica;
    }

    public void setDistanciaTeorica(Float distanciaTeorica) {
        this.distanciaTeorica = distanciaTeorica;
    }

    public Float getVelocidadTeorica() {
        return velocidadTeorica;
    }

    public void setVelocidadTeorica(Float velocidadTeorica) {
        this.velocidadTeorica = velocidadTeorica;
    }

    public Float getTiempoTeorico() {
        return tiempoTeorico;
    }

    public void setTiempoTeorico(Float tiempoTeorico) {
        this.tiempoTeorico = tiempoTeorico;
    }

    public Float getDistanciaReal() {
        return distanciaReal;
    }

    public void setDistanciaReal(Float distanciaReal) {
        this.distanciaReal = distanciaReal;
    }

    public Float getVelocidadReal() {
        return velocidadReal;
    }

    public void setVelocidadReal(Float velocidadReal) {
        this.velocidadReal = velocidadReal;
    }

    public Float getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(Float tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @XmlTransient
    public List<Tramo> getTramoList() {
        return tramoList;
    }

    public void setTramoList(List<Tramo> tramoList) {
        this.tramoList = tramoList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRuta != null ? idRuta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ruta)) {
            return false;
        }
        Ruta other = (Ruta) object;
        if ((this.idRuta == null && other.idRuta != null) || (this.idRuta != null && !this.idRuta.equals(other.idRuta))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.ada.rutas.entities.Ruta[ idRuta=" + idRuta + " ]";
    }
    
}
