package com.ada.rutas;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.ada.rutas.Room.db.AppDB;
import com.ada.rutas.Room.entidades.PosicionRoom;
import com.ada.rutas.Room.entidades.RutaRoom;
import com.ada.rutas.Room.entidades.TramoRoom;
import com.ada.rutas.SQLite.daos.DaoPosicionSQLite;
import com.ada.rutas.SQLite.daos.DaoRutaSQLite;
import com.ada.rutas.SQLite.daos.DaoTramoSQLite;
import com.ada.rutas.SQLite.db.DbHelper;
import com.ada.rutas.SQLite.entidades.PosicionSQLite;
import com.ada.rutas.SQLite.entidades.RutaSQLite;
import com.ada.rutas.SQLite.entidades.TramoSQLite;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // SQLite
        System.out.println("---------- SQLITE ----------");
        DbHelper dbHelper = new DbHelper(MainActivity.this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        if (db != null) {
            System.out.println("BASE DE DATOS 'RUTAS SQLITE' CREADA");

            crearPosicionSQLite("Sevilla", 2f, 1f);
            crearPosicionSQLite("Huelva", 4f, 3f);
            crearPosicionSQLite("Cádiz", 6f, 5f);
            crearPosicionSQLite("Malaga", 8f, 7f);
            crearPosicionSQLite("Granada", 10f, 9f);
            crearPosicionSQLite("Almería", 12f, 11f);
            crearPosicionSQLite("Jaén", 14f, 13f);
            crearPosicionSQLite("Córdoba", 16f, 15f);
            crearPosicionSQLite("Prueba", 1f, 1f);

            crearTramoSQLite(0f, 1f, 2f, 3f, 4f, 5f, 0, 1, 2);
            crearTramoSQLite(6f, 7f, 8f, 9f, 10f, 11f, 100, 1, 3);
            crearTramoSQLite(12f, 13f, 14f, 15f, 16f, 17f, 0, 3, 2);
            crearTramoSQLite(18f, 19f, 20f, 21f, 22f, 23f, 0, 1, 4);
            crearTramoSQLite(24f, 25f, 26f, 27f, 28f, 29f, 100, 3, 4);
            crearTramoSQLite(30f, 31f, 32f, 33f, 34f, 35f, 100, 4, 6);
            crearTramoSQLite(36f, 37f, 38f, 39f, 40f, 41f, 0, 5, 6);
            crearTramoSQLite(42f, 43f, 44f, 45f, 46f, 47f, 200, 1, 8);
            crearTramoSQLite(48f, 49f, 50f, 51f, 52f, 53f, 200, 8, 7);
            crearTramoSQLite(54f, 55f, 56f, 57f, 58f, 59f, 200, 7, 5);

            crearRutaSQLite(0f, 1f, 2f, 3f, 4f, 5f, "Occidental");
            crearRutaSQLite(6f, 7f, 8f, 9f, 10f, 11f, "De la costa");
            crearRutaSQLite(12f, 13f, 14f, 15f, 16f, 17f, "Ruta de la playa");
            crearRutaSQLite(18f, 19f, 20f, 21f, 22f, 23f, "Ruta del interior");

            verPosicionIdSQLite(3); // Probado con 15, no existe
            verPosicionDescripcionSQLite("Jaén"); // Probado con Jaen, no existe
            verPosicionLatitudSQLite(4f); // Probado con 3, no existe
            verPosicionLongitudSQLite(3f); // Probado con 4, no existe

            verTramoIdSQLite(5); // Probado con 15, no existe

            verRutaIdSQLite(3); // Probado con 15, no existe
            verRutaDescripcionSQLite("Ruta del interior"); //Probado con "Ruta del interiorA", no existe

            editarPosicionSQLite(4, "Málaga", 4f, 4f);
            editarTramoSQLite(2, 4f, 4f, 4f, 4f, 4f, 4f, 4, 3, 4);
            editarRutaSQLite(2, 22f, 33f, 11f, 55f, 77f, 44f, "Ruta del Interior");

            eliminarPosicionSQLite(9); // Probado con 2, se encuentra en tramo
            eliminarTramoSQLite(1);
            eliminarRutaSQLite(1);

            verPosicionesSQLite();
            verTramosSQLite();
            verRutasSQLite();
        } else {
            System.out.println("ERROR AL CREAR LA BASE DE DATOS 'RUTAS SQLITE'");
        }

        // Room
        System.out.println("---------- ROOM ----------");
        crearPosicionRoom("Sevilla", 2f, 1f);
        crearPosicionRoom("Huelva", 4f, 3f);
        crearPosicionRoom("Cadiz", 0f, 0f);
        crearPosicionRoom("Málaga", 8f, 7f);
        crearPosicionRoom("Granada", 10f, 9f);
        crearPosicionRoom("Almería", 12f, 11f);
        crearPosicionRoom("Jaen", 14f, 13f);
        crearPosicionRoom("Córdoba", 16f, 15f);
        crearPosicionRoom("Prueba", 18f, 17f);

        crearTramoRoom(0f, 1f, 2f, 3f, 4f, 5f, 0, 1, 2);
        crearTramoRoom(6f, 7f, 8f, 9f, 10f, 11f, 100, 1, 3);
        crearTramoRoom(12f, 13f, 14f, 15f, 16f, 17f, 0, 3, 2);
        crearTramoRoom(18f, 19f, 20f, 21f, 22f, 23f, 0, 1, 4);
        crearTramoRoom(24f, 25f, 26f, 27f, 28f, 29f, 100, 3, 4);
        crearTramoRoom(30f, 31f, 32f, 33f, 34f, 35f, 100, 4, 6);
        crearTramoRoom(36f, 37f, 38f, 39f, 40f, 41f, 0, 5, 6);
        crearTramoRoom(42f, 43f, 44f, 45f, 46f, 47f, 200, 1, 8);
        crearTramoRoom(48f, 49f, 50f, 51f, 52f, 53f, 200, 8, 7);
        crearTramoRoom(54f, 55f, 56f, 57f, 58f, 59f, 200, 7, 5);

        crearRutaRoom(0f, 1f, 2f, 3f, 4f, 5f, "Occidental");
        crearRutaRoom(6f, 7f, 8f, 9f, 10f, 11f, "De la costa");
        crearRutaRoom(12f, 13f, 14f, 15f, 16f, 17f, "Ruta de la playa");
        crearRutaRoom(18f, 19f, 20f, 21f, 22f, 23f, "Ruta del interior");

        verPosicionIdRoom(4);
        verPosicionDescripcionRoom("Jaen");
        verPosicionLatitudRoom(2f);
        verPosicionLongitudRoom(3f);

        verTramoIdRoom(1);

        verRutaIdRoom(1);
        verRutaDescripcionRoom("Ruta del interior");

        editarPosicionRoom(3, "Cádiz", 6f, 5f);
        editarTramoRoom(2, 4f, 4f, 4f, 4f, 4f, 4f, 100, 1, 3);
        editarRutaRoom(2, 1f, 2f, 3f, 4f, 5f, 6f, "De la Costa");

        eliminarPosicionRoom(9);
        eliminarTramoRoom(1);
        eliminarRutaRoom(1);
        verPosicionesRoom();
        verTramosRoom();
        verRutasRoom();

    }

    private void crearPosicionSQLite(String descripcion, float latitud, float longitud) {
        PosicionSQLite posicionSQLite = new PosicionSQLite();
        posicionSQLite.setDescripcion(descripcion);
        posicionSQLite.setLatitud(latitud);
        posicionSQLite.setLongitud(longitud);
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        daoPosicionSQLite.crearPosicion(posicionSQLite);
    }

    private void crearRutaSQLite(float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, String descripcion) {
        RutaSQLite rutaSQLite = new RutaSQLite();
        rutaSQLite.setDistancia_teorica(distancia_teorica);
        rutaSQLite.setDistancia_real(distancia_real);
        rutaSQLite.setVelocidad_teorica(velocidad_teorica);
        rutaSQLite.setVelocidad_real(velocidad_real);
        rutaSQLite.setTiempo_teorico(tiempo_teorico);
        rutaSQLite.setTiempo_real(tiempo_real);
        rutaSQLite.setDescripcion(descripcion);
        DaoRutaSQLite daoRutaSQLite = new DaoRutaSQLite(this);
        daoRutaSQLite.crearRuta(rutaSQLite);
    }

    private void crearTramoSQLite(float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, int rumbo_teorico, int nodo_inicial, int nodo_final) {

        if ((buscarPosicionIDSQLite(nodo_inicial) != null) && (buscarPosicionIDSQLite(nodo_final) != null)) {
            TramoSQLite tramoSQLite = new TramoSQLite();
            tramoSQLite.setDistancia_teorica(distancia_teorica);
            tramoSQLite.setDistancia_real(distancia_real);
            tramoSQLite.setVelocidad_teorica(velocidad_teorica);
            tramoSQLite.setVelocidad_real(velocidad_real);
            tramoSQLite.setTiempo_teorico(tiempo_teorico);
            tramoSQLite.setTiempo_real(tiempo_real);
            tramoSQLite.setRumbo_teorico(rumbo_teorico);
            tramoSQLite.setNodo_inicial(buscarPosicionIDSQLite(nodo_inicial));
            tramoSQLite.setNodo_final(buscarPosicionIDSQLite(nodo_final));
            DaoTramoSQLite daoTramoSQLite = new DaoTramoSQLite(this);
            daoTramoSQLite.crearTramo(tramoSQLite);
        } else {
            System.out.println("No existen los nodos indicados");
        }


    }

    private PosicionSQLite buscarPosicionDescripcionSQLite(String descripcion) {
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        return daoPosicionSQLite.buscarPosicionDescripcion(descripcion);
    }

    private PosicionSQLite buscarPosicionIDSQLite(int id) {
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        return daoPosicionSQLite.buscarPosicionId(id);
    }

    private PosicionSQLite buscarPosicionLatitudSQLite(float latitud) {
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        return daoPosicionSQLite.buscarPosicionLatitud(latitud);
    }

    private PosicionSQLite buscarPosicionLongitudSQLite(float longitud) {
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        return daoPosicionSQLite.buscarPosicionLongitud(longitud);
    }

    private RutaSQLite buscarRutaDescripcionSQLite(String descripcion) {
        DaoRutaSQLite daoRutaSQLite = new DaoRutaSQLite(this);
        return daoRutaSQLite.buscarRutaDescripcion(descripcion);
    }

    private RutaSQLite buscarRutaIDSQLite(int id) {
        DaoRutaSQLite daoRutaSQLite = new DaoRutaSQLite(this);
        return daoRutaSQLite.buscarRutaId(id);
    }

    private TramoSQLite buscarTramoIDSQLite(int id) {
        DaoTramoSQLite daoTramoSQLite = new DaoTramoSQLite(this);
        return daoTramoSQLite.buscarTramoId(id);
    }

    private void editarPosicionSQLite(int id, String descripcion, float latitud, float longitud) {
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        PosicionSQLite posicionSQLite = new PosicionSQLite();
        posicionSQLite.setId_posicion(id);
        posicionSQLite.setLongitud(longitud);
        posicionSQLite.setLatitud(latitud);
        posicionSQLite.setDescripcion(descripcion);

        if (!daoPosicionSQLite.actualizarPosicion(posicionSQLite)) {
            System.out.println("No se ha podido actualizar la posición con id " + id);
        } else {
            daoPosicionSQLite.actualizarPosicion(posicionSQLite);
            System.out.println("Posición con id " + id + " actualizada");
        }

    }

    private void editarRutaSQLite(int id, float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, String descripcion) {
        DaoRutaSQLite daoRutaSQLite = new DaoRutaSQLite(this);
        RutaSQLite rutaSQLite = new RutaSQLite();
        rutaSQLite.setId_ruta(id);
        rutaSQLite.setDistancia_teorica(distancia_teorica);
        rutaSQLite.setDistancia_real(distancia_real);
        rutaSQLite.setVelocidad_teorica(velocidad_teorica);
        rutaSQLite.setVelocidad_real(velocidad_real);
        rutaSQLite.setTiempo_teorico(tiempo_teorico);
        rutaSQLite.setTiempo_real(tiempo_real);
        rutaSQLite.setDescripcion(descripcion);

        if (!daoRutaSQLite.actualizarRuta(rutaSQLite)) {
            System.out.println("No se ha podido actualizar la posición con id " + id);
        } else {
            daoRutaSQLite.actualizarRuta(rutaSQLite);
            System.out.println("Ruta con id " + id + " actualizada");
        }
    }

    private void editarTramoSQLite(int id, float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, int rumbo_teorico, int nodo_inicial, int nodo_final) {
        DaoTramoSQLite daoTramoSQLite = new DaoTramoSQLite(this);
        TramoSQLite tramoSQLite = new TramoSQLite();
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);

        if ((buscarPosicionIDSQLite(nodo_inicial) != null) && (buscarPosicionIDSQLite(nodo_final) != null)) {
            tramoSQLite.setId_tramo(id);
            tramoSQLite.setDistancia_teorica(distancia_teorica);
            tramoSQLite.setDistancia_real(distancia_real);
            tramoSQLite.setVelocidad_teorica(velocidad_teorica);
            tramoSQLite.setVelocidad_real(velocidad_real);
            tramoSQLite.setTiempo_teorico(tiempo_teorico);
            tramoSQLite.setTiempo_real(tiempo_real);
            tramoSQLite.setRumbo_teorico(rumbo_teorico);
            tramoSQLite.setNodo_inicial(buscarPosicionIDSQLite(nodo_inicial));
            tramoSQLite.setNodo_final(buscarPosicionIDSQLite(nodo_final));
        } else {
            System.out.println("No existen los nodos indicados ");
        }

        if (!daoTramoSQLite.actualizarTramo(tramoSQLite)) {
            System.out.println("No se ha podido actualizar el tramo con id " + id);
        } else {
            daoTramoSQLite.actualizarTramo(tramoSQLite);
            System.out.println("Tramo con id " + id + " actualizado");
        }
    }

    private void eliminarPosicionSQLite(int id) {
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        DaoTramoSQLite daoTramoSQLite = new DaoTramoSQLite(this);
        ArrayList<TramoSQLite> listaTramo = daoTramoSQLite.verTramos();
        ArrayList<PosicionSQLite> listaPosicion = daoPosicionSQLite.verPosiciones();
        TramoSQLite tramoSQLite = null;
        boolean encTramo = false;
        boolean encPosicion = false;

        for (int i = 0; i < listaTramo.size() && !encTramo; i++) {
            if (listaTramo.get(i).getNodo_inicial().getId_posicion() == id || listaTramo.get(i).getNodo_final().getId_posicion() == id) {
                tramoSQLite = listaTramo.get(i);
                encTramo = true;
            }
        }

        for (int i = 0; i < listaPosicion.size() && !encPosicion; i++) {
            if (listaPosicion.get(i).getId_posicion() == id) {
                encPosicion = true;
            }
        }

        if (encTramo) {
            System.out.println("No es posible eliminar la posición con id " + id + " ya que se encuentra en el tramo con id " + tramoSQLite.getId_tramo());
        } else if (encPosicion) {
            System.out.println("Posición con id " + id + " eliminada");
            daoPosicionSQLite.eliminarPosicion(id);
        }
    }

    private void eliminarRutaSQLite(int id) {
        DaoRutaSQLite daoRutaSQLite = new DaoRutaSQLite(this);

        if (daoRutaSQLite.eliminarRuta(id)) {
            daoRutaSQLite.eliminarRuta(id);
        } else {
            System.out.println("No se ha podido eliminar la ruta con id " + id);
        }
    }

    private void eliminarTramoSQLite(int id) {
        DaoTramoSQLite daoTramoSQLite = new DaoTramoSQLite(this);

        if (daoTramoSQLite.eliminarTramo(id)) {
            daoTramoSQLite.eliminarTramo(id);
        } else {
            System.out.println("No se ha podido eliminar el tramo con id " + id);
        }
    }

    private void verPosicionesSQLite() {
        DaoPosicionSQLite daoPosicionSQLite = new DaoPosicionSQLite(this);
        ArrayList<PosicionSQLite> listaPosicion = daoPosicionSQLite.verPosiciones();

        System.out.println("----- Lista de posiciones: SQLite -----");
        for (int i = 0; i < listaPosicion.size(); i++) {
            System.out.println(" - Posición: " + listaPosicion.get(i).getId_posicion());
            System.out.println("     Longitud: " + listaPosicion.get(i).getLongitud() + " - Latitud: " + listaPosicion.get(i).getLatitud());
            System.out.println("     Descripción: " + listaPosicion.get(i).getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verRutasSQLite() {
        DaoRutaSQLite daoRutaSQLite = new DaoRutaSQLite(this);
        ArrayList<RutaSQLite> listaRuta = daoRutaSQLite.verRutas();

        System.out.println("----- Lista de rutas: SQLite -----");
        for (int i = 0; i < listaRuta.size(); i++) {
            System.out.println(" - Ruta: " + listaRuta.get(i).getId_ruta());
            System.out.println("     Distancia teórica: " + listaRuta.get(i).getDistancia_teorica() + " - Velocidad teórica: " + listaRuta.get(i).getVelocidad_teorica() + " - Tiempo teórico: " + listaRuta.get(i).getTiempo_teorico());
            System.out.println("     Distancia real: " + listaRuta.get(i).getDistancia_real() + " - Velocidad real: " + listaRuta.get(i).getVelocidad_real() + " - Tiempo real: " + listaRuta.get(i).getTiempo_real());
            System.out.println("     Descripción: " + listaRuta.get(i).getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verTramosSQLite() {
        DaoTramoSQLite daoTramoSQLite = new DaoTramoSQLite(this);
        ArrayList<TramoSQLite> listaTramo = daoTramoSQLite.verTramos();

        System.out.println("----- Lista de tramos: SQLite -----");
        for (int i = 0; i < listaTramo.size(); i++) {
            System.out.println(" - Tramo: " + listaTramo.get(i).getId_tramo());
            System.out.println("     Distancia teórica: " + listaTramo.get(i).getDistancia_teorica() + " - Velocidad teórica: " + listaTramo.get(i).getVelocidad_teorica() + " - Tiempo teórico: " + listaTramo.get(i).getTiempo_teorico());
            System.out.println("     Distancia real: " + listaTramo.get(i).getDistancia_real() + " - Velocidad real: " + listaTramo.get(i).getVelocidad_real() + " - Tiempo real: " + listaTramo.get(i).getTiempo_real());
            System.out.println("     Rumbo teórico: " + listaTramo.get(i).getRumbo_teorico() + " - Nodo inicial: " + listaTramo.get(i).getNodo_inicial().getId_posicion() + " - Nodo final: " + listaTramo.get(i).getNodo_final().getId_posicion());
            System.out.println("-------------------------------");
        }
    }

    private void verPosicionDescripcionSQLite(String descripcion) {
        PosicionSQLite posicionSQLite = buscarPosicionDescripcionSQLite(descripcion);

        if (posicionSQLite == null) {
            System.out.println("No existe posición con dicha descripción");
        } else {
            System.out.println(" - Posición: " + posicionSQLite.getId_posicion());
            System.out.println("     Longitud: " + posicionSQLite.getLongitud() + " - Latitud: " + posicionSQLite.getLatitud());
            System.out.println("     Descripción: " + posicionSQLite.getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verPosicionIdSQLite(int id) {
        PosicionSQLite posicionSQLite = buscarPosicionIDSQLite(id);

        if (posicionSQLite == null) {
            System.out.println("No existe posición con dicha id");
        } else {
            System.out.println(" - Posición: " + posicionSQLite.getId_posicion());
            System.out.println("     Longitud: " + posicionSQLite.getLongitud() + " - Latitud: " + posicionSQLite.getLatitud());
            System.out.println("     Descripción: " + posicionSQLite.getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verPosicionLatitudSQLite(float latitud) {
        PosicionSQLite posicionSQLite = buscarPosicionLatitudSQLite(latitud);

        if (posicionSQLite == null) {
            System.out.println("No existe posición con dicha latitud");
        } else {
            System.out.println(" - Posición: " + posicionSQLite.getId_posicion());
            System.out.println("     Longitud: " + posicionSQLite.getLongitud() + " - Latitud: " + posicionSQLite.getLatitud());
            System.out.println("     Descripción: " + posicionSQLite.getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verPosicionLongitudSQLite(float longitud) {
        PosicionSQLite posicionSQLite = buscarPosicionLongitudSQLite(longitud);

        if (posicionSQLite == null) {
            System.out.println("No existe posición con dicha longitud");
        } else {
            System.out.println(" - Posición: " + posicionSQLite.getId_posicion());
            System.out.println("     Longitud: " + posicionSQLite.getLongitud() + " - Latitud: " + posicionSQLite.getLatitud());
            System.out.println("     Descripción: " + posicionSQLite.getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verRutaDescripcionSQLite(String descripcion) {
        RutaSQLite rutaSQLite = buscarRutaDescripcionSQLite(descripcion);

        if (rutaSQLite == null) {
            System.out.println("No existe ruta con dicha descripción");
        } else {
            System.out.println(" - Ruta: " + rutaSQLite.getId_ruta());
            System.out.println("     Distancia teórica: " + rutaSQLite.getDistancia_teorica() + " - Velocidad teórica: " + rutaSQLite.getVelocidad_teorica() + " - Tiempo teórico: " + rutaSQLite.getTiempo_teorico());
            System.out.println("     Distancia real: " + rutaSQLite.getDistancia_real() + " - Velocidad real: " + rutaSQLite.getVelocidad_real() + " - Tiempo real: " + rutaSQLite.getTiempo_real());
            System.out.println("     Descripción: " + rutaSQLite.getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verRutaIdSQLite(int id) {
        RutaSQLite rutaSQLite = buscarRutaIDSQLite(id);

        if (rutaSQLite == null) {
            System.out.println("No existe ruta con dicha id");
        } else {
            System.out.println(" - Ruta: " + rutaSQLite.getId_ruta());
            System.out.println("     Distancia teórica: " + rutaSQLite.getDistancia_teorica() + " - Velocidad teórica: " + rutaSQLite.getVelocidad_teorica() + " - Tiempo teórico: " + rutaSQLite.getTiempo_teorico());
            System.out.println("     Distancia real: " + rutaSQLite.getDistancia_real() + " - Velocidad real: " + rutaSQLite.getVelocidad_real() + " - Tiempo real: " + rutaSQLite.getTiempo_real());
            System.out.println("     Descripción: " + rutaSQLite.getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verTramoIdSQLite(int id) {
        TramoSQLite tramoSQLite = buscarTramoIDSQLite(id);

        if (tramoSQLite == null) {
            System.out.println("No existe tramo con dicha id");
        } else {
            System.out.println(" - Tramo: " + tramoSQLite.getId_tramo());
            System.out.println("     Distancia teórica: " + tramoSQLite.getDistancia_teorica() + " - Velocidad teórica: " + tramoSQLite.getVelocidad_teorica() + " - Tiempo teórico: " + tramoSQLite.getTiempo_teorico());
            System.out.println("     Distancia real: " + tramoSQLite.getDistancia_real() + " - Velocidad real: " + tramoSQLite.getVelocidad_real() + " - Tiempo real: " + tramoSQLite.getTiempo_real());
            System.out.println("     Rumbo teórico: " + tramoSQLite.getRumbo_teorico() + " - Nodo inicial: " + tramoSQLite.getNodo_inicial().getId_posicion() + " - Nodo final: " + tramoSQLite.getNodo_final().getId_posicion());
            System.out.println("-------------------------------");
        }
    }

    private void crearPosicionRoom(String descripcion, float latitud, float longitud) {
        PosicionRoom posicionRoom = new PosicionRoom();
        posicionRoom.setDescripcion(descripcion);
        posicionRoom.setLatitud(latitud);
        posicionRoom.setLongitud(longitud);
        AppDB.getAppDB(getApplicationContext()).daoPosicion().crearPosicion(posicionRoom);
    }

    private void crearRutaRoom(float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, String descripcion) {
        RutaRoom rutaRoom = new RutaRoom();
        rutaRoom.setDistancia_teorica(distancia_teorica);
        rutaRoom.setDistancia_real(distancia_real);
        rutaRoom.setVelocidad_teorica(velocidad_teorica);
        rutaRoom.setVelocidad_real(velocidad_real);
        rutaRoom.setTiempo_teorico(tiempo_teorico);
        rutaRoom.setTiempo_real(tiempo_real);
        rutaRoom.setDescripcion(descripcion);
        AppDB.getAppDB(getApplicationContext()).daoRuta().crearRuta(rutaRoom);
    }

    private void crearTramoRoom(float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, int rumbo_teorico, int nodo_inicial, int nodo_final) {

        if (buscarPosicionIdRoom(nodo_inicial) != null && buscarPosicionIdRoom(nodo_final) != null) {
            TramoRoom tramoRoom = new TramoRoom();
            tramoRoom.setDistancia_teorica(distancia_teorica);
            tramoRoom.setDistancia_real(distancia_real);
            tramoRoom.setVelocidad_teorica(velocidad_teorica);
            tramoRoom.setVelocidad_real(velocidad_real);
            tramoRoom.setTiempo_teorico(tiempo_teorico);
            tramoRoom.setTiempo_real(tiempo_real);
            tramoRoom.setRumbo_teorico(rumbo_teorico);
            tramoRoom.setNodo_inicial(nodo_inicial);
            tramoRoom.setNodo_final(nodo_final);
            AppDB.getAppDB(getApplicationContext()).daoTramo().crearTramo(tramoRoom);
        } else {
            System.out.println("No existen los nodos indicados");
        }

    }

    private PosicionRoom buscarPosicionDescripcionRoom(String descripcion) {
        return AppDB.getAppDB(getApplicationContext()).daoPosicion().buscarPosicionDescripcion(descripcion);
    }

    private PosicionRoom buscarPosicionIdRoom(int id) {
        return AppDB.getAppDB(getApplicationContext()).daoPosicion().buscarPosicionId(id);
    }

    private PosicionRoom buscarPosicionLatitudRoom(float latitud) {
        return AppDB.getAppDB(getApplicationContext()).daoPosicion().buscarPosicionLatitud(latitud);
    }

    private PosicionRoom buscarPosicionLongitudRoom(float longitud) {
        return AppDB.getAppDB(getApplicationContext()).daoPosicion().buscarPosicionLongitud(longitud);
    }

    private RutaRoom buscarRutaIdRoom(int id) {
        return AppDB.getAppDB(getApplicationContext()).daoRuta().buscarRutaId(id);
    }

    private TramoRoom buscarTramoIDRoom(int id) {
        return AppDB.getAppDB(getApplicationContext()).daoTramo().buscarTramoId(id);
    }

    private void editarPosicionRoom(int id, String descripcion, float latitud, float longitud) {
        PosicionRoom posicionRoom = buscarPosicionIdRoom(id);

        if (posicionRoom == null) {
            System.out.println("No se ha podido actualizar la posición con id " + id);
        } else {
            posicionRoom.setDescripcion(descripcion);
            posicionRoom.setLatitud(latitud);
            posicionRoom.setLongitud(longitud);
            AppDB.getAppDB(getApplicationContext()).daoPosicion().actualizarPosicion(posicionRoom);
        }
    }

    private void editarRutaRoom(int id, float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, String descripcion) {
        RutaRoom rutaRoom = buscarRutaIdRoom(id);

        if (rutaRoom == null) {
            System.out.println("No se ha podido actualizar la ruta con id " + id);
        } else {
            rutaRoom.setDistancia_teorica(distancia_teorica);
            rutaRoom.setDistancia_real(distancia_real);
            rutaRoom.setVelocidad_teorica(velocidad_teorica);
            rutaRoom.setVelocidad_real(velocidad_real);
            rutaRoom.setTiempo_teorico(tiempo_teorico);
            rutaRoom.setTiempo_real(tiempo_real);
            rutaRoom.setDescripcion(descripcion);
            AppDB.getAppDB(getApplicationContext()).daoRuta().actualizarRuta(rutaRoom);
        }
    }

    private void editarTramoRoom(int id, float distancia_teorica, float distancia_real, float velocidad_teorica, float velocidad_real, float tiempo_teorico, float tiempo_real, int rumbo_teorico, int nodo_inicial, int nodo_final) {
        TramoRoom tramoRoom = buscarTramoIDRoom(id);

        if (tramoRoom == null) {
            System.out.println("No se ha podido actualizar el tramo con id " + id);
        } else {
            tramoRoom.setDistancia_teorica(distancia_teorica);
            tramoRoom.setDistancia_real(distancia_real);
            tramoRoom.setVelocidad_teorica(velocidad_teorica);
            tramoRoom.setVelocidad_real(velocidad_real);
            tramoRoom.setTiempo_teorico(tiempo_teorico);
            tramoRoom.setTiempo_real(tiempo_real);
            tramoRoom.setRumbo_teorico(rumbo_teorico);
            tramoRoom.setNodo_inicial(nodo_inicial);
            tramoRoom.setNodo_final(nodo_final);
            AppDB.getAppDB(getApplicationContext()).daoTramo().actualizarTramo(tramoRoom);
        }
    }

    private void eliminarPosicionRoom(int id) {
        PosicionRoom posicionRoom = buscarPosicionIdRoom(id);
        List<TramoRoom> listaTramo = AppDB.getAppDB(getApplicationContext()).daoTramo().verTramos();
        boolean encTra = false;

        for (int i = 0; i < listaTramo.size() && !encTra; i++) {
            if (listaTramo.get(i).getNodo_inicial() == id || listaTramo.get(i).getNodo_final() == id) {
                encTra = true;
            }
        }

        if (encTra) {
            System.out.println("No se puede eliminar una posición contenida en un tramo");
        } else if (!encTra) {
            AppDB.getAppDB(getApplicationContext()).daoPosicion().eliminarPosicion(posicionRoom);
        } else {
            System.out.println("No se puede eliminar la posición con id " + id);
        }
    }

    private void eliminarRutaRoom(int id) {
        RutaRoom rutaRoom = buscarRutaIdRoom(id);

        if (rutaRoom != null) {
            AppDB.getAppDB(getApplicationContext()).daoRuta().eliminarRuta(rutaRoom);
        } else {
            System.out.println("No se puede eliminar la ruta con id " + id);
        }
    }

    private void eliminarTramoRoom(int id) {
        TramoRoom tramoRoom = buscarTramoIDRoom(id);

        if (tramoRoom != null) {
            AppDB.getAppDB(getApplicationContext()).daoTramo().eliminarTramo(tramoRoom);
        } else {
            System.out.println("No se puede eliminar el tramo con id " + id);
        }
    }

    private void verPosicionDescripcionRoom(String descripcion) {
        PosicionRoom posicionRoom = buscarPosicionDescripcionRoom(descripcion);

        if (posicionRoom != null) {
            System.out.println(" - Posición: " + posicionRoom.getId_posicion());
            System.out.println("     Longitud: " + posicionRoom.getLongitud() + " - Latitud: " + posicionRoom.getLatitud());
            System.out.println("     Descripción: " + posicionRoom.getDescripcion());
            System.out.println("-------------------------------");
        } else {
            System.out.println("No existe posición con dicha id");
        }
    }

    private void verPosicionIdRoom(int id) {
        PosicionRoom posicionRoom = buscarPosicionIdRoom(id);

        if (posicionRoom != null) {
            System.out.println(" - Posición: " + posicionRoom.getId_posicion());
            System.out.println("     Longitud: " + posicionRoom.getLongitud() + " - Latitud: " + posicionRoom.getLatitud());
            System.out.println("     Descripción: " + posicionRoom.getDescripcion());
            System.out.println("-------------------------------");
        } else {
            System.out.println("No existe posición con dicha id");
        }
    }

    private void verPosicionLatitudRoom(float latitud) {
        PosicionRoom posicionRoom = buscarPosicionLatitudRoom(latitud);

        if (posicionRoom != null) {
            System.out.println(" - Posición: " + posicionRoom.getId_posicion());
            System.out.println("     Longitud: " + posicionRoom.getLongitud() + " - Latitud: " + posicionRoom.getLatitud());
            System.out.println("     Descripción: " + posicionRoom.getDescripcion());
            System.out.println("-------------------------------");
        } else {
            System.out.println("No existe posición con dicha latitud");
        }
    }

    private void verPosicionLongitudRoom(float longitud) {
        PosicionRoom posicionRoom = buscarPosicionLongitudRoom(longitud);

        if (posicionRoom != null) {
            System.out.println(" - Posición: " + posicionRoom.getId_posicion());
            System.out.println("     Longitud: " + posicionRoom.getLongitud() + " - Latitud: " + posicionRoom.getLatitud());
            System.out.println("     Descripción: " + posicionRoom.getDescripcion());
            System.out.println("-------------------------------");
        } else {
            System.out.println("No existe posición con dicha longitud");
        }
    }

    private void verPosicionesRoom() {
        List<PosicionRoom> listaPosicion = AppDB.getAppDB(getApplicationContext()).daoPosicion().verPosiciones();

        System.out.println("----- Lista de posiciones: Room -----");
        for (int i = 0; i < listaPosicion.size(); i++) {
            System.out.println(" - Posición: " + listaPosicion.get(i).getId_posicion());
            System.out.println("     Longitud: " + listaPosicion.get(i).getLongitud() + " - Latitud: " + listaPosicion.get(i).getLatitud());
            System.out.println("     Descripción: " + listaPosicion.get(i).getDescripcion());
            System.out.println("-------------------------------");
        }
    }

    private void verRutaDescripcionRoom(String descripcion) {
        RutaRoom rutaRoom = AppDB.getAppDB(getApplicationContext()).daoRuta().buscarRutaDescripcion(descripcion);

        if (rutaRoom != null) {
            System.out.println(" - Ruta: " + rutaRoom.getId_ruta());
            System.out.println("     Distancia teórica: " + rutaRoom.getDistancia_teorica() + " - Velocidad teórica: " + rutaRoom.getVelocidad_teorica() + " - Tiempo teórico: " + rutaRoom.getTiempo_teorico());
            System.out.println("     Distancia real: " + rutaRoom.getDistancia_real() + " - Velocidad real: " + rutaRoom.getVelocidad_real() + " - Tiempo real: " + rutaRoom.getTiempo_real());
            System.out.println("     Descripción: " + rutaRoom.getDescripcion());
            System.out.println("-------------------------------");
        } else {
            System.out.println("No existe ruta con dicha descripción");
        }

    }

    private void verRutaIdRoom(int id) {
        RutaRoom rutaRoom = AppDB.getAppDB(getApplicationContext()).daoRuta().buscarRutaId(id);

        if (rutaRoom != null) {
            System.out.println(" - Ruta: " + rutaRoom.getId_ruta());
            System.out.println("     Distancia teórica: " + rutaRoom.getDistancia_teorica() + " - Velocidad teórica: " + rutaRoom.getVelocidad_teorica() + " - Tiempo teórico: " + rutaRoom.getTiempo_teorico());
            System.out.println("     Distancia real: " + rutaRoom.getDistancia_real() + " - Velocidad real: " + rutaRoom.getVelocidad_real() + " - Tiempo real: " + rutaRoom.getTiempo_real());
            System.out.println("     Descripción: " + rutaRoom.getDescripcion());
            System.out.println("-------------------------------");
        } else {
            System.out.println("No existe ruta con dicha id");
        }
    }

    private void verRutasRoom() {
        List<RutaRoom> listaRuta = AppDB.getAppDB(getApplicationContext()).daoRuta().verRutas();

        System.out.println("----- Lista de rutas: Room -----");
        for (int i = 0; i < listaRuta.size(); i++) {
            System.out.println(" - Ruta: " + listaRuta.get(i).getId_ruta());
            System.out.println("     Distancia teórica: " + listaRuta.get(i).getDistancia_teorica() + " - Velocidad teórica: " + listaRuta.get(i).getVelocidad_teorica() + " - Tiempo teórico: " + listaRuta.get(i).getTiempo_teorico());
            System.out.println("     Distancia real: " + listaRuta.get(i).getDistancia_real() + " - Velocidad real: " + listaRuta.get(i).getVelocidad_real() + " - Tiempo real: " + listaRuta.get(i).getTiempo_real());
            System.out.println("     Descripción: " + listaRuta.get(i).getDescripcion());
            System.out.println("-------------------------------");
        }

    }

    private void verTramoIdRoom(int id) {
        TramoRoom tramoRoom = AppDB.getAppDB(getApplicationContext()).daoTramo().buscarTramoId(id);

        if (tramoRoom != null) {
            System.out.println(" - Tramo: " + tramoRoom.getId_tramo());
            System.out.println("     Distancia teórica: " + tramoRoom.getDistancia_teorica() + " - Velocidad teórica: " + tramoRoom.getVelocidad_teorica() + " - Tiempo teórico: " + tramoRoom.getTiempo_teorico());
            System.out.println("     Distancia real: " + tramoRoom.getDistancia_real() + " - Velocidad real: " + tramoRoom.getVelocidad_real() + " - Tiempo real: " + tramoRoom.getTiempo_real());
            System.out.println("     Rumbo teórico: " + tramoRoom.getRumbo_teorico() + " - Nodo inicial: " + tramoRoom.getNodo_inicial() + " - Nodo final: " + tramoRoom.getNodo_final());
            System.out.println("-------------------------------");
        } else {
            System.out.println("No existe tramo con dicha id");
        }

    }

    private void verTramosRoom() {
        List<TramoRoom> listaTramo = AppDB.getAppDB(getApplicationContext()).daoTramo().verTramos();

        System.out.println("----- Lista de tramos: Room -----");
        for (int i = 0; i < listaTramo.size(); i++) {
            System.out.println(" - Tramo: " + listaTramo.get(i).getId_tramo());
            System.out.println("     Distancia teórica: " + listaTramo.get(i).getDistancia_teorica() + " - Velocidad teórica: " + listaTramo.get(i).getVelocidad_teorica() + " - Tiempo teórico: " + listaTramo.get(i).getTiempo_teorico());
            System.out.println("     Distancia real: " + listaTramo.get(i).getDistancia_real() + " - Velocidad real: " + listaTramo.get(i).getVelocidad_real() + " - Tiempo real: " + listaTramo.get(i).getTiempo_real());
            System.out.println("     Rumbo teórico: " + listaTramo.get(i).getRumbo_teorico() + " - Nodo inicial: " + listaTramo.get(i).getNodo_inicial() + " - Nodo final: " + listaTramo.get(i).getNodo_final());
            System.out.println("-------------------------------");
        }

    }

}