package com.ada.rutas.SQLite.interfaces;

import com.ada.rutas.SQLite.entidades.PosicionSQLite;
import com.ada.rutas.SQLite.entidades.TramoSQLite;

import java.util.ArrayList;

public interface IDaoTramo {

    boolean actualizarTramo(TramoSQLite tramoSQLite);

    TramoSQLite buscarTramoId(int id);

    long crearTramo(TramoSQLite tramoSQLite);

    boolean eliminarTramo(int id);

    ArrayList<TramoSQLite> verTramos();


}
