package com.ada.rutas.Room.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.ada.rutas.Room.db.AppDB;
import com.ada.rutas.Room.entidades.RutaRoom;

import java.util.List;
@Dao
public interface IDaoRuta {

    @Update
    void actualizarRuta(RutaRoom rutaRoom);

    @Insert
    void crearRuta(RutaRoom rutaRoom);

    @Delete
    void eliminarRuta(RutaRoom rutaRoom);

    @Query("SELECT * FROM " + AppDB.T_RUTA_NOMBRE + " WHERE descripcion LIKE :descripcion")
    RutaRoom buscarRutaDescripcion(String descripcion);

    @Query("SELECT * FROM " + AppDB.T_RUTA_NOMBRE + " WHERE id_ruta LIKE :id")
    RutaRoom buscarRutaId(int id);

    @Query("SELECT * FROM " + AppDB.T_RUTA_NOMBRE)
    List<RutaRoom> verRutas();


}
