package com.ada.rutas.SQLite.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.ada.rutas.SQLite.db.DbHelper;
import com.ada.rutas.SQLite.entidades.PosicionSQLite;
import com.ada.rutas.SQLite.interfaces.IDaoPosicion;

import java.util.ArrayList;

public class DaoPosicionSQLite extends DbHelper implements IDaoPosicion {

    Context context;

    // Constructor
    public DaoPosicionSQLite(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public boolean actualizarPosicion(PosicionSQLite posicionSQLite) {

        boolean correcto;

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        try {
            db.execSQL("UPDATE " + T_POSICION_NOMBRE + " SET descripcion = '" + posicionSQLite.getDescripcion() +
                    "', longitud = '" + posicionSQLite.getLongitud() +
                    "', latitud = '" + posicionSQLite.getLatitud() +
                    "' WHERE id_posicion = '" + posicionSQLite.getId_posicion() + "'");
            correcto = true;
        } catch (Exception ex) {
            ex.toString();
            correcto = false;
        } finally {
            db.close();
        }

        return correcto;
    }

    @Override
    public PosicionSQLite buscarPosicionDescripcion(String descripcion) {
        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        PosicionSQLite posicionSQLite = null;

        Cursor cursor = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE descripcion = '" + descripcion + "' LIMIT 1", null);

        if (cursor.moveToFirst()) {
            posicionSQLite = new PosicionSQLite();
            posicionSQLite.setId_posicion(cursor.getInt(0));
            posicionSQLite.setDescripcion(cursor.getString(1));
            posicionSQLite.setLatitud(cursor.getFloat(2));
            posicionSQLite.setLongitud(cursor.getFloat(3));
        }

        cursor.close();
        return posicionSQLite;
    }

    @Override
    public PosicionSQLite buscarPosicionId(int id) {
        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        PosicionSQLite posicionSQLite = null;

        Cursor cursor = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE id_posicion = " + id + " LIMIT 1", null);

        if (cursor.moveToFirst()) {
            posicionSQLite = new PosicionSQLite();
            posicionSQLite.setId_posicion(cursor.getInt(0));
            posicionSQLite.setDescripcion(cursor.getString(1));
            posicionSQLite.setLatitud(cursor.getFloat(2));
            posicionSQLite.setLongitud(cursor.getFloat(3));
        }

        cursor.close();
        return posicionSQLite;
    }

    @Override
    public PosicionSQLite buscarPosicionLatitud(float latitud) {
        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        PosicionSQLite posicionSQLite = null;

        Cursor cursor = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE latitud = " + latitud + " LIMIT 1", null);

        if (cursor.moveToFirst()) {
            posicionSQLite = new PosicionSQLite();
            posicionSQLite.setId_posicion(cursor.getInt(0));
            posicionSQLite.setDescripcion(cursor.getString(1));
            posicionSQLite.setLatitud(cursor.getFloat(2));
            posicionSQLite.setLongitud(cursor.getFloat(3));
        }

        cursor.close();
        return posicionSQLite;
    }

    @Override
    public PosicionSQLite buscarPosicionLongitud(float longitud) {
        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        PosicionSQLite posicionSQLite = null;

        Cursor cursor = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE longitud = " + longitud + " LIMIT 1", null);

        if (cursor.moveToFirst()) {
            posicionSQLite = new PosicionSQLite();
            posicionSQLite.setId_posicion(cursor.getInt(0));
            posicionSQLite.setDescripcion(cursor.getString(1));
            posicionSQLite.setLatitud(cursor.getFloat(2));
            posicionSQLite.setLongitud(cursor.getFloat(3));
        }

        cursor.close();
        return posicionSQLite;
    }

    @Override
    public long crearPosicion(PosicionSQLite posicionSQLite) {

        long id = 0;

        try {
            DbHelper gestionBD = new DbHelper(this.context);
            SQLiteDatabase db = gestionBD.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("descripcion", posicionSQLite.getDescripcion());
            values.put("latitud", posicionSQLite.getLatitud());
            values.put("longitud", posicionSQLite.getLongitud());

            id = db.insert(T_POSICION_NOMBRE, null, values);
        } catch (Exception ex) {
            ex.toString();
        }

        return id;
    }

    @Override
    public boolean eliminarPosicion(int id) {

        boolean correcto;

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        try {
            db.execSQL("DELETE FROM " + T_POSICION_NOMBRE + " WHERE id_posicion = " + id);
            correcto = true;
        } catch (Exception ex) {
            ex.toString();
            correcto = false;
        } finally {
            db.close();
        }

        return correcto;
    }

    @Override
    public ArrayList<PosicionSQLite> verPosiciones() {

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        ArrayList<PosicionSQLite> posiciones = new ArrayList<>();
        PosicionSQLite posicionSQLite;
        Cursor cursor = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE, null);

        if (cursor.moveToFirst()) {
            do {
                posicionSQLite = new PosicionSQLite();
                posicionSQLite.setId_posicion(cursor.getInt(0));
                posicionSQLite.setDescripcion(cursor.getString(1));
                posicionSQLite.setLatitud(cursor.getFloat(2));
                posicionSQLite.setLongitud(cursor.getFloat(3));
                posiciones.add(posicionSQLite);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return posiciones;
    }
}
