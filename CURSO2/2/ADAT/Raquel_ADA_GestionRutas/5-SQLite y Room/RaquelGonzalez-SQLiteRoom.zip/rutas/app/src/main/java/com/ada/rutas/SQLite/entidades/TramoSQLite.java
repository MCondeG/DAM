package com.ada.rutas.SQLite.entidades;

public class TramoSQLite {

    private int id_tramo;
    private float distancia_teorica;
    private float distancia_real;
    private float velocidad_teorica;
    private float velocidad_real;
    private float tiempo_teorico;
    private float tiempo_real;
    private int rumbo_teorico;
    private PosicionSQLite nodo_inicial;
    private PosicionSQLite nodo_final;


    public TramoSQLite() {
    }

    public int getId_tramo() {
        return id_tramo;
    }

    public void setId_tramo(int id_tramo) {
        this.id_tramo = id_tramo;
    }

    public float getDistancia_teorica() {
        return distancia_teorica;
    }

    public void setDistancia_teorica(float distancia_teorica) {
        this.distancia_teorica = distancia_teorica;
    }

    public float getDistancia_real() {
        return distancia_real;
    }

    public void setDistancia_real(float distancia_real) {
        this.distancia_real = distancia_real;
    }

    public float getVelocidad_teorica() {
        return velocidad_teorica;
    }

    public void setVelocidad_teorica(float velocidad_teorica) {
        this.velocidad_teorica = velocidad_teorica;
    }

    public float getVelocidad_real() {
        return velocidad_real;
    }

    public void setVelocidad_real(float velocidad_real) {
        this.velocidad_real = velocidad_real;
    }

    public float getTiempo_teorico() {
        return tiempo_teorico;
    }

    public void setTiempo_teorico(float tiempo_teorico) {
        this.tiempo_teorico = tiempo_teorico;
    }

    public float getTiempo_real() {
        return tiempo_real;
    }

    public void setTiempo_real(float tiempo_real) {
        this.tiempo_real = tiempo_real;
    }

    public int getRumbo_teorico() {
        return rumbo_teorico;
    }

    public void setRumbo_teorico(int rumbo_teorico) {
        this.rumbo_teorico = rumbo_teorico;
    }

    public PosicionSQLite getNodo_inicial() {
        return nodo_inicial;
    }

    public void setNodo_inicial(PosicionSQLite nodo_inicial) {
        this.nodo_inicial = nodo_inicial;
    }

    public PosicionSQLite getNodo_final() {
        return nodo_final;
    }

    public void setNodo_final(PosicionSQLite nodo_final) {
        this.nodo_final = nodo_final;
    }
}
