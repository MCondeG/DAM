package com.ada.rutas.SQLite.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

// Clase DbHelper. Clase ayudante, proporciona los elementos para crear la base de datos y las tablas
public class DbHelper extends SQLiteOpenHelper {

    // Variables
    // Última versión
    private static final int DATABASE_VERSION = 1;
    // Nombre de la base de datos
    private static final String DATABASE_NOMBRE = "rutasqlite.db";
    // Nombre de las tablas
    public static final String T_POSICION_NOMBRE = "posicion";
    public static final String T_TRAMO_NOMBRE = "tramo";
    public static final String T_RUTA_NOMBRE = "ruta";
    public static final String T_TRAMO_RUTA_NOMBRE = "tramo_has_ruta";

    // Sentencia SQL para crear las tablas
    public static final String T_POSICION = "CREATE TABLE " + T_POSICION_NOMBRE + " ( id_posicion INTEGER PRIMARY KEY AUTOINCREMENT, descripcion TEXT, latitud REAL, longitud REAL )";
    public static final String T_TRAMO = "CREATE TABLE " + T_TRAMO_NOMBRE + " ( id_tramo INTEGER PRIMARY KEY AUTOINCREMENT, distancia_real REAL, distancia_teorica REAL, rumbo_teorico INTEGER, tiempo_real REAL, tiempo_teorico REAL, velocidad_real REAL, velocidad_teorica REAL, nodo_inicial INTEGER, nodo_final INTEGER, FOREIGN KEY (nodo_inicial) REFERENCES " + T_POSICION_NOMBRE + "(id_posicion), FOREIGN KEY (nodo_final) REFERENCES " + T_POSICION_NOMBRE + "(id_posicion))";
    public static final String T_RUTA = "CREATE TABLE " + T_RUTA_NOMBRE + " ( id_ruta INTEGER PRIMARY KEY AUTOINCREMENT, descripcion TEXT, distancia_real REAL, distancia_teorica REAL, tiempo_real REAL, tiempo_teorico REAL, velocidad_real REAL, velocidad_teorica REAL)";
    public static final String T_TRAMO_RUTA = "CREATE TABLE " + T_TRAMO_RUTA_NOMBRE + "( id_ruta INTEGER, id_tramo INTEGER, FOREIGN KEY (id_ruta) REFERENCES " + T_RUTA_NOMBRE + "(id_ruta), FOREIGN KEY (id_tramo) REFERENCES " + T_TRAMO_NOMBRE + "(id_tramo))";

    // Constructor
    public DbHelper(@Nullable Context context) {
        super(context, DATABASE_NOMBRE, null, DATABASE_VERSION);
    }

    // Método que se encarga de crear la base de datos
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(T_POSICION);
        db.execSQL(T_TRAMO);
        db.execSQL(T_RUTA);
        db.execSQL(T_TRAMO_RUTA);
    }

    // Método que comprueba si la versión actual y la última coincide. En caso de que no coincidan, actualiza
    @Override
    public void onUpgrade(SQLiteDatabase db, int v_old, int v_new) {
        db.execSQL("DROP TABLE " + T_TRAMO_RUTA_NOMBRE);
        db.execSQL("DROP TABLE " + T_RUTA_NOMBRE);
        db.execSQL("DROP TABLE " + T_TRAMO_NOMBRE);
        db.execSQL("DROP TABLE " + T_POSICION_NOMBRE);

        onCreate(db);
    }
}
