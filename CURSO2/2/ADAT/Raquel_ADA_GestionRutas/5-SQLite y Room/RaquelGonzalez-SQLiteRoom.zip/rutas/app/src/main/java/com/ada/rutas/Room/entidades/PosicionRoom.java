package com.ada.rutas.Room.entidades;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.ada.rutas.Room.db.AppDB;

@Entity(tableName = AppDB.T_POSICION_NOMBRE)
public class PosicionRoom {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_posicion")
    private int id_posicion;

    @ColumnInfo(name = "descripcion")
    private String descripcion;

    @ColumnInfo(name = "latitud")
    private float latitud;

    @ColumnInfo(name = "longitud")
    private float longitud;

    public PosicionRoom() {
    }

    public int getId_posicion() {
        return id_posicion;
    }

    public void setId_posicion(int id_posicion) {
        this.id_posicion = id_posicion;
    }

    public float getLongitud() {
        return longitud;
    }

    public void setLongitud(float longitud) {
        this.longitud = longitud;
    }

    public float getLatitud() {
        return latitud;
    }

    public void setLatitud(float latitud) {
        this.latitud = latitud;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
