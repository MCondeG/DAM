package com.ada.rutas.Room.entidades;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.ada.rutas.Room.db.AppDB;

@Entity(tableName = AppDB.T_RUTA_NOMBRE)
public class RutaRoom {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_ruta")
    private int id_ruta;

    @ColumnInfo(name = "distancia_teorica")
    private float distancia_teorica;

    @ColumnInfo(name = "distancia_real")
    private float distancia_real;

    @ColumnInfo(name = "velocidad_teorica")
    private float velocidad_teorica;

    @ColumnInfo(name = "velocidad_real")
    private float velocidad_real;

    @ColumnInfo(name = "tiempo_teorico")
    private float tiempo_teorico;

    @ColumnInfo(name = "tiempo_real")
    private float tiempo_real;

    @ColumnInfo(name = "descripcion")
    private String descripcion;

    public RutaRoom() {
    }

    public int getId_ruta() {
        return id_ruta;
    }

    public void setId_ruta(int id_ruta) {
        this.id_ruta = id_ruta;
    }

    public float getDistancia_teorica() {
        return distancia_teorica;
    }

    public void setDistancia_teorica(float distancia_teorica) {
        this.distancia_teorica = distancia_teorica;
    }

    public float getDistancia_real() {
        return distancia_real;
    }

    public void setDistancia_real(float distancia_real) {
        this.distancia_real = distancia_real;
    }

    public float getVelocidad_teorica() {
        return velocidad_teorica;
    }

    public void setVelocidad_teorica(float velocidad_teorica) {
        this.velocidad_teorica = velocidad_teorica;
    }

    public float getVelocidad_real() {
        return velocidad_real;
    }

    public void setVelocidad_real(float velocidad_real) {
        this.velocidad_real = velocidad_real;
    }

    public float getTiempo_teorico() {
        return tiempo_teorico;
    }

    public void setTiempo_teorico(float tiempo_teorico) {
        this.tiempo_teorico = tiempo_teorico;
    }

    public float getTiempo_real() {
        return tiempo_real;
    }

    public void setTiempo_real(float tiempo_real) {
        this.tiempo_real = tiempo_real;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
