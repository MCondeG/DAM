package com.ada.rutas.SQLite.interfaces;

import com.ada.rutas.SQLite.entidades.PosicionSQLite;

import java.util.ArrayList;

public interface IDaoPosicion {

    boolean actualizarPosicion(PosicionSQLite pos);

    PosicionSQLite buscarPosicionDescripcion(String descripcion);

    PosicionSQLite buscarPosicionId(int id);

    PosicionSQLite buscarPosicionLatitud(float latitud);

    PosicionSQLite buscarPosicionLongitud(float longitud);

    long crearPosicion(PosicionSQLite pos);

    boolean eliminarPosicion(int id);

    ArrayList<PosicionSQLite> verPosiciones();


}
