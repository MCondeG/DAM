package com.ada.rutas.SQLite.interfaces;

import com.ada.rutas.SQLite.entidades.RutaSQLite;

import java.util.ArrayList;

public interface IDaoRuta {

    boolean actualizarRuta(RutaSQLite rutaSQLite);

    RutaSQLite buscarRutaId(int id);

    RutaSQLite buscarRutaDescripcion(String descripcion);

    long crearRuta(RutaSQLite rutaSQLite);

    boolean eliminarRuta(int id);

    ArrayList<RutaSQLite> verRutas();


}
