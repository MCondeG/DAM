package com.ada.rutas.Room.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.ada.rutas.Room.db.AppDB;
import com.ada.rutas.Room.entidades.TramoRoom;

import java.util.List;

@Dao
public interface IDaoTramo {

    @Update
    void actualizarTramo(TramoRoom tramoRoom);

    @Insert
    void crearTramo(TramoRoom tramoRoom);

    @Delete
    void eliminarTramo(TramoRoom tramoRoom);

    @Query("SELECT * FROM " + AppDB.T_TRAMO_NOMBRE + " WHERE id_tramo LIKE :id")
    TramoRoom buscarTramoId(int id);

    @Query("SELECT * FROM " + AppDB.T_TRAMO_NOMBRE)
    List<TramoRoom> verTramos();

}
