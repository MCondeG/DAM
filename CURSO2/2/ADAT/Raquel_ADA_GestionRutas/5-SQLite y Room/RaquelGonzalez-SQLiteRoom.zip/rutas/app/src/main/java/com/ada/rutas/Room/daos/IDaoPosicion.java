package com.ada.rutas.Room.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.ada.rutas.Room.db.AppDB;
import com.ada.rutas.Room.entidades.PosicionRoom;

import java.util.List;

@Dao
public interface IDaoPosicion {

    @Update
    void actualizarPosicion(PosicionRoom posicionRoom);

    @Insert
    void crearPosicion(PosicionRoom posicionRoom);

    @Delete
    void eliminarPosicion(PosicionRoom posicionRoom);

    @Query("SELECT * FROM " + AppDB.T_POSICION_NOMBRE + " WHERE descripcion LIKE :descripcion")
    PosicionRoom buscarPosicionDescripcion(String descripcion);

    @Query("SELECT * FROM " + AppDB.T_POSICION_NOMBRE + " WHERE id_posicion LIKE :id")
    PosicionRoom buscarPosicionId(int id);

    @Query("SELECT * FROM " + AppDB.T_POSICION_NOMBRE + " WHERE latitud LIKE :latitud")
    PosicionRoom buscarPosicionLatitud(float latitud);

    @Query("SELECT * FROM " + AppDB.T_POSICION_NOMBRE + " WHERE longitud LIKE :longitud")
    PosicionRoom buscarPosicionLongitud(float longitud);

    @Query("SELECT * FROM " + AppDB.T_POSICION_NOMBRE)
    List<PosicionRoom> verPosiciones();

}
