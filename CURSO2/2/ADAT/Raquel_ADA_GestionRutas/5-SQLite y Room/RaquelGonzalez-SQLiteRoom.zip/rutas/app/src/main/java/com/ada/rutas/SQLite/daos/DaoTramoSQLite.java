package com.ada.rutas.SQLite.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ada.rutas.SQLite.db.DbHelper;
import com.ada.rutas.SQLite.entidades.PosicionSQLite;
import com.ada.rutas.SQLite.entidades.TramoSQLite;
import com.ada.rutas.SQLite.interfaces.IDaoTramo;

import java.util.ArrayList;

public class DaoTramoSQLite extends DbHelper implements IDaoTramo {

    Context context;

    public DaoTramoSQLite(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public boolean actualizarTramo(TramoSQLite tramoSQLite) {

        boolean correcto;

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        try {
            db.execSQL("UPDATE " + T_TRAMO_NOMBRE + " SET distancia_teorica = '" + tramoSQLite.getDistancia_teorica() +
                    "', distancia_real = '" + tramoSQLite.getDistancia_real() +
                    "', velocidad_teorica = '" + tramoSQLite.getVelocidad_teorica() +
                    "', velocidad_real = '" + tramoSQLite.getVelocidad_real() +
                    "', tiempo_teorico = '" + tramoSQLite.getTiempo_teorico() +
                    "', tiempo_real = '" + tramoSQLite.getTiempo_real() +
                    "', rumbo_teorico = '" + tramoSQLite.getRumbo_teorico() +
                    "', nodo_inicial = '" + tramoSQLite.getNodo_inicial().getId_posicion() +
                    "', nodo_final = '" + tramoSQLite.getNodo_final().getId_posicion() +
                    "' WHERE id_tramo = '" + tramoSQLite.getId_tramo() + "'");
            correcto = true;
        } catch (Exception ex) {
            ex.toString();
            correcto = false;
        } finally {
            db.close();
        }

        return correcto;
    }

    @Override
    public TramoSQLite buscarTramoId(int id) {
        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        TramoSQLite tramoSQLite = null;
        PosicionSQLite nodoInicial, nodoFinal;

        Cursor cursor = db.rawQuery("SELECT * FROM " + T_TRAMO_NOMBRE + " WHERE id_tramo = " + id + " LIMIT 1", null);

        if (cursor.moveToFirst()) {
            tramoSQLite = new TramoSQLite();
            tramoSQLite.setId_tramo(cursor.getInt(0));
            tramoSQLite.setDistancia_teorica(cursor.getFloat(2));
            tramoSQLite.setDistancia_real(cursor.getFloat(1));
            tramoSQLite.setVelocidad_teorica(cursor.getFloat(7));
            tramoSQLite.setVelocidad_real(cursor.getFloat(6));
            tramoSQLite.setTiempo_teorico(cursor.getFloat(5));
            tramoSQLite.setTiempo_real(cursor.getFloat(4));
            tramoSQLite.setRumbo_teorico(cursor.getInt(3));

            Cursor cursorInicial = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE id_posicion = " + cursor.getInt(8) + " LIMIT 1", null);
            if (cursorInicial.moveToFirst()) {
                nodoInicial = new PosicionSQLite();
                nodoInicial.setId_posicion(cursorInicial.getInt(0));
                nodoInicial.setDescripcion(cursorInicial.getString(1));
                nodoInicial.setLatitud(cursorInicial.getFloat(2));
                nodoInicial.setLongitud(cursorInicial.getFloat(3));
                tramoSQLite.setNodo_inicial(nodoInicial);
                cursorInicial.close();
            }

            Cursor cursorFinal = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE id_posicion = " + cursor.getInt(9) + " LIMIT 1", null);
            if (cursorFinal.moveToFirst()) {
                nodoFinal = new PosicionSQLite();
                nodoFinal.setId_posicion(cursorFinal.getInt(0));
                nodoFinal.setDescripcion(cursorFinal.getString(1));
                nodoFinal.setLatitud(cursorFinal.getFloat(2));
                nodoFinal.setLongitud(cursorFinal.getFloat(3));
                tramoSQLite.setNodo_final(nodoFinal);
                cursorFinal.close();
            }
        }

        cursor.close();
        return tramoSQLite;
    }

    @Override
    public long crearTramo(TramoSQLite tramoSQLite) {

        long id = 0;

        try {
            DbHelper gestionBD = new DbHelper(this.context);
            SQLiteDatabase db = gestionBD.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("distancia_teorica", tramoSQLite.getDistancia_teorica());
            values.put("distancia_real", tramoSQLite.getDistancia_real());
            values.put("tiempo_teorico", tramoSQLite.getTiempo_teorico());
            values.put("tiempo_real", tramoSQLite.getTiempo_real());
            values.put("velocidad_teorica", tramoSQLite.getVelocidad_teorica());
            values.put("velocidad_real", tramoSQLite.getVelocidad_real());
            values.put("rumbo_teorico", tramoSQLite.getRumbo_teorico());
            values.put("nodo_inicial", tramoSQLite.getNodo_inicial().getId_posicion());
            values.put("nodo_final", tramoSQLite.getNodo_final().getId_posicion());

            id = db.insert(T_TRAMO_NOMBRE, null, values);
        } catch (Exception ex) {
            ex.toString();
        }

        return id;
    }

    @Override
    public boolean eliminarTramo(int id) {

        boolean correcto;

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        try {
            db.execSQL("DELETE FROM " + T_TRAMO_NOMBRE + " WHERE id_tramo = " + id);
            correcto = true;
        } catch (Exception ex) {
            ex.toString();
            correcto = false;
        } finally {
            db.close();
        }

        return correcto;
    }

    @Override
    public ArrayList<TramoSQLite> verTramos() {

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        ArrayList<TramoSQLite> tramos = new ArrayList<>();
        TramoSQLite tramoSQLite;
        PosicionSQLite nodoInicial, nodoFinal;
        Cursor cursor = db.rawQuery("SELECT * FROM " + T_TRAMO_NOMBRE, null);

        if (cursor.moveToFirst()) {
            do {
                tramoSQLite = new TramoSQLite();
                tramoSQLite.setId_tramo(cursor.getInt(0));
                tramoSQLite.setDistancia_teorica(cursor.getFloat(2));
                tramoSQLite.setDistancia_real(cursor.getFloat(1));
                tramoSQLite.setVelocidad_teorica(cursor.getFloat(7));
                tramoSQLite.setVelocidad_real(cursor.getFloat(6));
                tramoSQLite.setTiempo_teorico(cursor.getFloat(5));
                tramoSQLite.setTiempo_real(cursor.getFloat(4));
                tramoSQLite.setRumbo_teorico(cursor.getInt(3));

                Cursor cursorInicial = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE id_posicion = " + cursor.getInt(8) + " LIMIT 1", null);
                if (cursorInicial.moveToFirst()) {
                    nodoInicial = new PosicionSQLite();
                    nodoInicial.setId_posicion(cursorInicial.getInt(0));
                    nodoInicial.setDescripcion(cursorInicial.getString(1));
                    nodoInicial.setLatitud(cursorInicial.getFloat(2));
                    nodoInicial.setLongitud(cursorInicial.getFloat(3));
                    tramoSQLite.setNodo_inicial(nodoInicial);
                    cursorInicial.close();
                }

                Cursor cursorFinal = db.rawQuery("SELECT * FROM " + T_POSICION_NOMBRE + " WHERE id_posicion = " + cursor.getInt(9) + " LIMIT 1", null);
                if (cursorFinal.moveToFirst()) {
                    nodoFinal = new PosicionSQLite();
                    nodoFinal.setId_posicion(cursorFinal.getInt(0));
                    nodoFinal.setDescripcion(cursorFinal.getString(1));
                    nodoFinal.setLatitud(cursorFinal.getFloat(2));
                    nodoFinal.setLongitud(cursorFinal.getFloat(3));
                    tramoSQLite.setNodo_final(nodoFinal);
                    cursorFinal.close();
                }
                tramos.add(tramoSQLite);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return tramos;
    }
}
