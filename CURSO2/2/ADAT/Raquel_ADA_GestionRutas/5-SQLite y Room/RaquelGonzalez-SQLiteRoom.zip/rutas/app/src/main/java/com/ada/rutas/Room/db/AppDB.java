package com.ada.rutas.Room.db;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.ada.rutas.Room.daos.IDaoPosicion;
import com.ada.rutas.Room.daos.IDaoRuta;
import com.ada.rutas.Room.daos.IDaoTramo;
import com.ada.rutas.Room.entidades.PosicionRoom;
import com.ada.rutas.Room.entidades.RutaRoom;
import com.ada.rutas.Room.entidades.TramoRoom;

@Database(entities = {PosicionRoom.class, TramoRoom.class, RutaRoom.class}, version = 2,  exportSchema = false)
public abstract class AppDB extends RoomDatabase {

    public static AppDB INSTANCE;

    public static final String NOMBRE_DB = "rutaroom";
    public static final String T_POSICION_NOMBRE = "posicion";
    public static final String T_TRAMO_NOMBRE = "tramo";
    public static final String T_RUTA_NOMBRE = "ruta";
    public static final String T_TRAMO_RUTA_NOMBRE = "tramoruta";


    public abstract IDaoPosicion daoPosicion();

    public abstract IDaoTramo daoTramo();

    public abstract IDaoRuta daoRuta();

    public static AppDB getAppDB(Context context) {

        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(), AppDB.class, NOMBRE_DB)
                    .allowMainThreadQueries() // Permite funcionar en el Main sin necesidad de hilos
                    .addMigrations(MIGRATION_1_2)
                    .addMigrations(MIGRATION_2_3)
                    .build();
        }
        return INSTANCE;
    }

    public void destroyInstance() {
        INSTANCE = null;
    }

    public static Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE " + T_POSICION_NOMBRE + " ( id_posicion INTEGER PRIMARY KEY AUTOINCREMENT, descripcion TEXT, latitud REAL, longitud REAL )");
        }
    };

    public static Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE " + T_TRAMO_NOMBRE + " ( id_tramo INTEGER PRIMARY KEY AUTOINCREMENT, distancia_real REAL, distancia_teorica REAL, rumbo_teorico INTEGER, tiempo_real REAL, tiempo_teorico REAL, velocidad_real REAL, velocidad_teorica REAL, nodo_inicial INTEGER, nodo_final INTEGER, FOREIGN KEY (nodo_inicial) REFERENCES " + T_POSICION_NOMBRE + "(id_posicion), FOREIGN KEY (nodo_final) REFERENCES " + T_POSICION_NOMBRE + "(id_posicion))");
            database.execSQL("CREATE TABLE " + T_RUTA_NOMBRE + " ( id_ruta INTEGER PRIMARY KEY AUTOINCREMENT, descripcion TEXT, distancia_real REAL, distancia_teorica REAL, tiempo_real REAL, tiempo_teorico REAL, velocidad_real REAL, velocidad_teorica REAL)");
            database.execSQL("CREATE TABLE " + T_TRAMO_RUTA_NOMBRE + "( id_ruta INTEGER, id_tramo INTEGER, FOREIGN KEY (id_ruta) REFERENCES " + T_RUTA_NOMBRE + "(id_ruta), FOREIGN KEY (id_tramo) REFERENCES " + T_TRAMO_NOMBRE + "(id_tramo))");
        }
    };

}
