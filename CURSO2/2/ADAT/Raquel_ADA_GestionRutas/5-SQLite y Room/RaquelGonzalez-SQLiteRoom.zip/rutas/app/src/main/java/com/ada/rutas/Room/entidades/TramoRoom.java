package com.ada.rutas.Room.entidades;

import static androidx.room.ForeignKey.CASCADE;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import com.ada.rutas.Room.db.AppDB;

@Entity(tableName = AppDB.T_TRAMO_NOMBRE,
        indices =
                {@Index(value = {"nodo_inicial"}),
                @Index(value = {"nodo_final"})},
        foreignKeys = {
                @ForeignKey(entity = PosicionRoom.class,
                        parentColumns = "id_posicion",
                        childColumns = "nodo_inicial",
                        onDelete = CASCADE),
                @ForeignKey(entity = PosicionRoom.class,
                        parentColumns = "id_posicion",
                        childColumns = "nodo_final",
                        onDelete = CASCADE)}
)
public class TramoRoom {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_tramo")
    private int id_tramo;

    @ColumnInfo(name = "distancia_teorica")
    private float distancia_teorica;

    @ColumnInfo(name = "distancia_real")
    private float distancia_real;

    @ColumnInfo(name = "velocidad_teorica")
    private float velocidad_teorica;

    @ColumnInfo(name = "velocidad_real")
    private float velocidad_real;

    @ColumnInfo(name = "tiempo_teorico")
    private float tiempo_teorico;

    @ColumnInfo(name = "tiempo_real")
    private float tiempo_real;

    @ColumnInfo(name = "rumbo_teorico")
    private int rumbo_teorico;

    @ColumnInfo(name = "nodo_inicial")
    private int nodo_inicial;

    @ColumnInfo(name = "nodo_final")
    private int nodo_final;

    public TramoRoom() {
    }

    public int getId_tramo() {
        return id_tramo;
    }

    public void setId_tramo(int id_tramo) {
        this.id_tramo = id_tramo;
    }

    public float getDistancia_teorica() {
        return distancia_teorica;
    }

    public void setDistancia_teorica(float distancia_teorica) {
        this.distancia_teorica = distancia_teorica;
    }

    public float getDistancia_real() {
        return distancia_real;
    }

    public void setDistancia_real(float distancia_real) {
        this.distancia_real = distancia_real;
    }

    public float getVelocidad_teorica() {
        return velocidad_teorica;
    }

    public void setVelocidad_teorica(float velocidad_teorica) {
        this.velocidad_teorica = velocidad_teorica;
    }

    public float getVelocidad_real() {
        return velocidad_real;
    }

    public void setVelocidad_real(float velocidad_real) {
        this.velocidad_real = velocidad_real;
    }

    public float getTiempo_teorico() {
        return tiempo_teorico;
    }

    public void setTiempo_teorico(float tiempo_teorico) {
        this.tiempo_teorico = tiempo_teorico;
    }

    public float getTiempo_real() {
        return tiempo_real;
    }

    public void setTiempo_real(float tiempo_real) {
        this.tiempo_real = tiempo_real;
    }

    public int getRumbo_teorico() {
        return rumbo_teorico;
    }

    public void setRumbo_teorico(int rumbo_teorico) {
        this.rumbo_teorico = rumbo_teorico;
    }

    public int getNodo_inicial() {
        return nodo_inicial;
    }

    public void setNodo_inicial(int nodo_inicial) {
        this.nodo_inicial = nodo_inicial;
    }

    public int getNodo_final() {
        return nodo_final;
    }

    public void setNodo_final(int nodo_final) {
        this.nodo_final = nodo_final;
    }
}
