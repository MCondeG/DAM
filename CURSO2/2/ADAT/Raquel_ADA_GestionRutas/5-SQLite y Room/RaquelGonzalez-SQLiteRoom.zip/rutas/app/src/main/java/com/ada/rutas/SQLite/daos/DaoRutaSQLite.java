package com.ada.rutas.SQLite.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.ada.rutas.SQLite.db.DbHelper;
import com.ada.rutas.SQLite.entidades.RutaSQLite;
import com.ada.rutas.SQLite.interfaces.IDaoRuta;

import java.util.ArrayList;

public class DaoRutaSQLite extends DbHelper implements IDaoRuta {

    Context context;

    public DaoRutaSQLite(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public boolean actualizarRuta(RutaSQLite rutaSQLite) {

        boolean correcto;

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        try {
            db.execSQL("UPDATE " + T_RUTA_NOMBRE + " SET distancia_teorica = '" + rutaSQLite.getDistancia_teorica() +
                    "', distancia_real = '" + rutaSQLite.getDistancia_real() +
                    "', velocidad_teorica = '" + rutaSQLite.getVelocidad_teorica() +
                    "', velocidad_real = '" + rutaSQLite.getVelocidad_real() +
                    "', tiempo_teorico = '" + rutaSQLite.getTiempo_teorico() +
                    "', tiempo_real = '" + rutaSQLite.getTiempo_real() +
                    "', descripcion = '" + rutaSQLite.getDescripcion() +
                    "' WHERE id_ruta = '" + rutaSQLite.getId_ruta() + "'");
            correcto = true;
        } catch (Exception ex) {
            ex.toString();
            correcto = false;
        } finally {
            db.close();
        }

        return correcto;
    }

    @Override
    public RutaSQLite buscarRutaDescripcion(String descripcion) {
        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        RutaSQLite rutaSQLite = null;

        Cursor cursor = db.rawQuery("SELECT * FROM " + T_RUTA_NOMBRE + " WHERE descripcion = '" + descripcion + "' LIMIT 1", null);

        if (cursor.moveToFirst()) {
            rutaSQLite = new RutaSQLite();
            rutaSQLite.setId_ruta(cursor.getInt(0));
            rutaSQLite.setDistancia_teorica(cursor.getFloat(3));
            rutaSQLite.setDistancia_real(cursor.getFloat(2));
            rutaSQLite.setVelocidad_teorica(cursor.getFloat(7));
            rutaSQLite.setVelocidad_real(cursor.getFloat(6));
            rutaSQLite.setTiempo_teorico(cursor.getFloat(5));
            rutaSQLite.setTiempo_real(cursor.getFloat(4));
            rutaSQLite.setDescripcion(cursor.getString(1));
        }

        cursor.close();
        return rutaSQLite;
    }

    @Override
    public RutaSQLite buscarRutaId(int id) {
        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        RutaSQLite rutaSQLite = null;

        Cursor cursor = db.rawQuery("SELECT * FROM " + T_RUTA_NOMBRE + " WHERE id_ruta = " + id + " LIMIT 1", null);

        if (cursor.moveToFirst()) {
            rutaSQLite = new RutaSQLite();
            rutaSQLite.setId_ruta(cursor.getInt(0));
            rutaSQLite.setDistancia_teorica(cursor.getFloat(3));
            rutaSQLite.setDistancia_real(cursor.getFloat(2));
            rutaSQLite.setVelocidad_teorica(cursor.getFloat(7));
            rutaSQLite.setVelocidad_real(cursor.getFloat(6));
            rutaSQLite.setTiempo_teorico(cursor.getFloat(5));
            rutaSQLite.setTiempo_real(cursor.getFloat(4));
            rutaSQLite.setDescripcion(cursor.getString(1));
        }

        cursor.close();
        return rutaSQLite;
    }

    @Override
    public long crearRuta(RutaSQLite rutaSQLite) {
        long id = 0;

        try {
            DbHelper gestionBD = new DbHelper(this.context);
            SQLiteDatabase db = gestionBD.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("distancia_teorica", rutaSQLite.getDistancia_teorica());
            values.put("distancia_real", rutaSQLite.getDistancia_real());
            values.put("tiempo_teorico", rutaSQLite.getTiempo_teorico());
            values.put("tiempo_real", rutaSQLite.getTiempo_real());
            values.put("velocidad_teorica", rutaSQLite.getVelocidad_teorica());
            values.put("velocidad_real", rutaSQLite.getVelocidad_real());
            values.put("descripcion", rutaSQLite.getDescripcion());

            id = db.insert(T_RUTA_NOMBRE, null, values);
        } catch (Exception ex) {
            ex.toString();
        }

        return id;
    }

    @Override
    public boolean eliminarRuta(int id) {
        boolean correcto;

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        try {
            db.execSQL("DELETE FROM " + T_RUTA_NOMBRE + " WHERE id_ruta = " + id);
            correcto = true;
        } catch (Exception ex) {
            ex.toString();
            correcto = false;
        } finally {
            db.close();
        }

        return correcto;
    }

    @Override
    public ArrayList<RutaSQLite> verRutas() {

        DbHelper gestionBD = new DbHelper(this.context);
        SQLiteDatabase db = gestionBD.getWritableDatabase();

        ArrayList<RutaSQLite> rutas = new ArrayList<>();
        RutaSQLite rutaSQLite;
        Cursor cursor = db.rawQuery("SELECT * FROM " + T_RUTA_NOMBRE, null);

        if (cursor.moveToFirst()) {
            do {
                rutaSQLite = new RutaSQLite();
                rutaSQLite.setId_ruta(cursor.getInt(0));
                rutaSQLite.setDistancia_teorica(cursor.getFloat(3));
                rutaSQLite.setDistancia_real(cursor.getFloat(2));
                rutaSQLite.setVelocidad_teorica(cursor.getFloat(7));
                rutaSQLite.setVelocidad_real(cursor.getFloat(6));
                rutaSQLite.setTiempo_teorico(cursor.getFloat(5));
                rutaSQLite.setTiempo_real(cursor.getFloat(4));
                rutaSQLite.setDescripcion(cursor.getString(1));
                rutas.add(rutaSQLite);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return rutas;
    }
}

